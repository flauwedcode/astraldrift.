package com.astraldrift.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.astraldrift.app.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.Canvas

/**
 * The centrepiece UI element: a 270° arc showing XP progress, with a cerulean
 * glow that blooms outward from the progress tip. Designed to look like a
 * star-chart readout on a Drifter's display.
 */
@Composable
fun ArcProgressIndicator(
    progress: Float,
    level: Int,
    skillName: String,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 700),
        label = "arcProgress"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val diameter = size.minDimension * 0.88f
            val radius = diameter / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            val topLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = Size(diameter, diameter)
            val stroke = diameter * 0.068f
            val startAngle = 135f
            val maxSweep = 270f
            val sweep = maxSweep * animatedProgress

            // Background track
            drawArc(
                color = DarkPanel,
                startAngle = startAngle,
                sweepAngle = maxSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )

            // Faint secondary ring for depth
            drawArc(
                color = NebulaPurple,
                startAngle = startAngle,
                sweepAngle = maxSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
                alpha = 0.12f
            )

            if (sweep > 0.5f) {
                // Outer glow bloom (three passes, decreasing alpha)
                for (i in 3 downTo 1) {
                    drawArc(
                        color = CeruleanGlow,
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke + i * 9f, cap = StrokeCap.Round),
                        alpha = 0.055f * i
                    )
                }
                // Main progress arc
                drawArc(
                    color = CeruleanGlow,
                    startAngle = startAngle,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                // Glowing dot at progress tip
                val tipRad = Math.toRadians((startAngle + sweep).toDouble())
                val tipX = center.x + radius * cos(tipRad).toFloat()
                val tipY = center.y + radius * sin(tipRad).toFloat()
                drawCircle(CeruleanGlow, radius = stroke * 0.9f, center = Offset(tipX, tipY), alpha = 0.25f)
                drawCircle(CeruleanGlow, radius = stroke * 0.6f, center = Offset(tipX, tipY), alpha = 0.55f)
                drawCircle(Starlight, radius = stroke * 0.28f, center = Offset(tipX, tipY))
            }
        }

        // Centred level and skill text overlaid on the canvas.
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = level.toString(),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 52.sp,
                color = Starlight
            )
            Text(
                text = skillName.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 3.sp,
                color = StarlightMuted
            )
        }
    }
}
