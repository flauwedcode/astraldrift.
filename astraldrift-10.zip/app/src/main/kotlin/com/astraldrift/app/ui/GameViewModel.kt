package com.astraldrift.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.astraldrift.app.game.GameRepository
import com.astraldrift.engine.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// --------------- UI data classes ---------------

data class SkillUiItem(
    val id: SkillId,
    val display: String,
    val type: SkillType,
    val level: Int,
    val progress: Float,
    val masteryHint: String
)

data class ActionUiItem(
    val id: String,
    val display: String,
    val skillDisplay: String,
    val levelRequired: Int,
    val isSelected: Boolean,
    val isUnlocked: Boolean
)

data class InventoryUiItem(
    val name: String,
    val qty: Int,
    val rarityLabel: String,
    val rarityArgb: Long   // 0xFFRRGGBB
)

data class GameUiState(
    val loaded: Boolean = false,
    // Train screen
    val activity: String = "",
    val skillName: String = "",
    val level: Int = 0,
    val progress: Float = 0f,
    val totalCompletions: Long = 0L,
    val proficiencyMultiplier: Float = 1f,
    val selectedActionId: String = "",
    val availableActions: List<ActionUiItem> = emptyList(),
    // Character screen
    val skills: List<SkillUiItem> = emptyList(),
    // Vault screen
    val essence: Double = 0.0,
    val essencePerMinute: Double = 0.0,
    val essenceCeilingLevel: Int = EssenceConfig.CEILING_LEVEL,
    val inventoryItems: List<InventoryUiItem> = emptyList(),
    // Meta
    val runningSeconds: Long = 0L,
    val welcomeBackSeconds: Long = 0L
)

// --------------- ViewModel ---------------

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(app)
    private val engine = GameEngine()

    private lateinit var player: Player
    private var selectedActionId = repo.defaultActionId
    private var actionState: GameEngine.ActionState? = null
    private var totalCompletions = 0L
    private val startedAt = System.currentTimeMillis()
    private var welcomeBackSeconds = 0L

    private val _ui = MutableStateFlow(GameUiState())
    val ui: StateFlow<GameUiState> = _ui.asStateFlow()

    private var loopJob: Job? = null

    init {
        viewModelScope.launch {
            val loaded = repo.loadOrCreate()
            player = loaded.player
            selectedActionId = loaded.selectedActionId
            actionState = GameEngine.ActionState(currentAction())
            welcomeBackSeconds = loaded.offlineSeconds
            refresh()
            startLoop()
        }
    }

    private fun currentAction() =
        Skills.actions.first { it.id == selectedActionId }

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = viewModelScope.launch {
            var sinceSave = 0
            while (isActive) {
                delay(1000L)
                val r = engine.tick(player, actionState!!, 1000L)
                player.essence.accrue(System.currentTimeMillis())
                totalCompletions += r.completions
                welcomeBackSeconds = 0L
                refresh()
                if (++sinceSave >= 15) { repo.save(player, selectedActionId); sinceSave = 0 }
            }
        }
    }

    fun selectAction(id: String) {
        if (!::player.isInitialized || id == selectedActionId) return
        selectedActionId = id
        actionState = GameEngine.ActionState(currentAction())
        refresh()
        viewModelScope.launch { repo.save(player, selectedActionId) }
    }

    fun skipOneMinute() {
        if (!::player.isInitialized) return
        val r = engine.tick(player, actionState!!, 60_000L)
        totalCompletions += r.completions
        player.essence.lastAccrualEpochMs -= 60_000L
        player.essence.accrue(System.currentTimeMillis())
        refresh()
    }

    fun spendEssenceOn(skillId: SkillId) {
        if (!::player.isInitialized) return
        EssenceSpending.spendToCeiling(player, skillId)
        refresh()
        viewModelScope.launch { repo.save(player, selectedActionId) }
    }

    fun saveNow() {
        if (!::player.isInitialized) return
        viewModelScope.launch { repo.save(player, selectedActionId) }
    }

    private fun refresh() {
        if (!::player.isInitialized) return
        val action = currentAction()
        val skill = player.skill(action.skill)
        _ui.value = GameUiState(
            loaded = true,
            activity = action.display,
            skillName = action.skill.display,
            level = skill.level,
            progress = skill.progressToNext().toFloat().coerceIn(0f, 1f),
            totalCompletions = totalCompletions,
            proficiencyMultiplier = Mastery.actionSpeedMultiplier(skill.level).toFloat(),
            selectedActionId = selectedActionId,
            availableActions = Skills.actions.map { a ->
                ActionUiItem(
                    id = a.id,
                    display = a.display,
                    skillDisplay = a.skill.display,
                    levelRequired = a.levelRequirement,
                    isSelected = a.id == selectedActionId,
                    isUnlocked = player.skill(a.skill).level >= a.levelRequirement
                )
            },
            skills = SkillId.values().map { id ->
                val p = player.skill(id)
                SkillUiItem(
                    id = id,
                    display = id.display,
                    type = id.type,
                    level = p.level,
                    progress = p.progressToNext().toFloat().coerceIn(0f, 1f),
                    masteryHint = masteryHint(id, p.level)
                )
            },
            essence = player.essence.balance,
            essencePerMinute = player.essence.currentRatePerMs() * 60_000.0,
            inventoryItems = player.inventory.map { st ->
                InventoryUiItem(st.item.name, st.quantity, st.item.rarity.displayName, rarityArgb(st.item.rarity))
            },
            runningSeconds = (System.currentTimeMillis() - startedAt) / 1000,
            welcomeBackSeconds = welcomeBackSeconds
        )
    }

    private fun masteryHint(id: SkillId, level: Int): String {
        if (level < 100) return "Keep training..."
        val chunks = level / 100
        return when (id.type) {
            SkillType.GATHERING -> "+${chunks}% Gather, +${chunks * 5} stats"
            SkillType.PRODUCTION -> "+${chunks}% Production, +${chunks * 5} stats"
            SkillType.COMBAT -> "+${chunks * 5} Power, +${chunks}% Haste"
        }
    }

    private fun rarityArgb(rarity: Rarity): Long = when (rarity) {
        Rarity.COMMON -> 0xFF9AA0A6L
        Rarity.UNCOMMON -> 0xFF3CB371L
        Rarity.RARE -> 0xFF00B7FFL
        Rarity.EPIC -> 0xFF6D4AFFL
        Rarity.CELESTIAL -> 0xFFE8B339L
        Rarity.MYTHIC -> 0xFFFF5470L
    }
}
