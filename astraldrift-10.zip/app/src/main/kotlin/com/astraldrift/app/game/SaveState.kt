package com.astraldrift.app.game

import com.astraldrift.server.PlayerSnapshot
import kotlinx.serialization.Serializable

/**
 * What we actually write to disk: the engine's durable PlayerSnapshot plus the
 * client-only bits it doesn't know about (which action you were idling, and when
 * we last saved — used to compute offline progress on the next launch).
 */
@Serializable
data class SaveState(
    val player: PlayerSnapshot,
    val selectedActionId: String,
    val lastSavedEpochMs: Long
)
