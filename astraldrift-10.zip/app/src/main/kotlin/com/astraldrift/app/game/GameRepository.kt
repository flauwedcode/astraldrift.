package com.astraldrift.app.game

import android.content.Context
import com.astraldrift.app.data.AppDatabase
import com.astraldrift.app.data.SaveEntity
import com.astraldrift.engine.*
import com.astraldrift.server.PlayerCodec
import kotlinx.serialization.json.Json

/**
 * Bridges the engine and Room. On load it reconstructs the Player and applies
 * everything earned while the app was closed — Essence (real-time) and offline
 * action progress (capped at 12h by the engine). On save it banks Essence up to
 * the moment of writing so nothing is lost.
 */
class GameRepository(context: Context) {

    private val dao = AppDatabase.get(context).saveDao()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val engine = GameEngine()

    val defaultActionId = "dive_shoal"

    data class Loaded(
        val player: Player,
        val selectedActionId: String,
        val offlineSeconds: Long
    )

    suspend fun loadOrCreate(): Loaded {
        val entity = dao.load()
            ?: return Loaded(Player(name = "You"), defaultActionId, 0L)

        val state = json.decodeFromString(SaveState.serializer(), entity.json)
        val player = PlayerCodec.fromSnapshot(state.player)
        val now = System.currentTimeMillis()
        val offlineMs = (now - state.lastSavedEpochMs).coerceAtLeast(0L)

        // Offline Essence: the account's stored timestamp drives accrual to "now".
        player.essence.accrue(now)

        // Offline action progress for whatever you were idling.
        val action = Skills.actions.firstOrNull { it.id == state.selectedActionId }
        if (action != null && offlineMs > 0) {
            engine.applyOffline(player, GameEngine.ActionState(action), offlineMs)
        }

        return Loaded(player, state.selectedActionId, offlineMs / 1000)
    }

    suspend fun save(player: Player, selectedActionId: String) {
        val now = System.currentTimeMillis()
        player.essence.accrue(now)              // bank Essence up to the save moment
        player.essence.snapshotResonance(player) // offline rate reflects worn gear
        val state = SaveState(PlayerCodec.toSnapshot(player), selectedActionId, now)
        dao.save(SaveEntity(0, json.encodeToString(SaveState.serializer(), state), now))
    }
}
