package com.astraldrift.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.astraldrift.app.ui.GameViewModel
import com.astraldrift.app.ui.screens.CharacterScreen
import com.astraldrift.app.ui.screens.TrainScreen
import com.astraldrift.app.ui.screens.VaultScreen
import com.astraldrift.app.ui.theme.*
import com.astraldrift.engine.SkillId

enum class AstralTab(val label: String, val icon: ImageVector) {
    TRAIN("Train", Icons.Default.Bolt),
    CHARACTER("Character", Icons.Default.Person),
    VAULT("Vault", Icons.Default.Star)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AstralDriftTheme {
                AstralApp()
            }
        }
    }
}

@Composable
fun AstralApp(vm: GameViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    var currentTab by remember { mutableStateOf(AstralTab.TRAIN) }

    // Save whenever the app is sent to the background.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) vm.saveNow()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!ui.loaded) {
        Box(
            Modifier.fillMaxSize().background(DeepSpace),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = CeruleanGlow)
                Spacer(Modifier.height(16.dp))
                Text("Entering the drift...",
                    fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = StarlightMuted)
            }
        }
        return
    }

    Scaffold(
        containerColor = DeepSpace,
        bottomBar = {
            NavigationBar(
                containerColor = DarkPanel,
                tonalElevation = 0.dp
            ) {
                AstralTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = {
                            Text(
                                tab.label,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CeruleanGlow,
                            selectedTextColor = CeruleanGlow,
                            unselectedIconColor = StarlightMuted,
                            unselectedTextColor = StarlightMuted,
                            indicatorColor = NebulaPurple.copy(alpha = 0.25f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (currentTab) {
                AstralTab.TRAIN -> TrainScreen(
                    ui = ui,
                    onSelectAction = { vm.selectAction(it) },
                    onSkip = { vm.skipOneMinute() }
                )
                AstralTab.CHARACTER -> CharacterScreen(ui = ui)
                AstralTab.VAULT -> VaultScreen(
                    ui = ui,
                    onSpendEssence = { skillId: SkillId -> vm.spendEssenceOn(skillId) }
                )
            }

            // Welcome-back banner (shown once, auto-clears after first tick).
            if (ui.welcomeBackSeconds > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 16.dp, start = 20.dp, end = 20.dp)
                        .background(DarkPanel, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        "Welcome back — ${formatDuration(ui.welcomeBackSeconds)} of drift banked.",
                        color = CeruleanGlow,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

private fun formatDuration(seconds: Long): String = when {
    seconds < 60 -> "${seconds}s"
    seconds < 3600 -> "${seconds / 60}m"
    seconds < 86400 -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
    else -> "${seconds / 86400}d ${(seconds % 86400) / 3600}h"
}
