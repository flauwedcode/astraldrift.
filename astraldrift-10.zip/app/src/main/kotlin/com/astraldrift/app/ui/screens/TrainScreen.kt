package com.astraldrift.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.astraldrift.app.ui.ActionUiItem
import com.astraldrift.app.ui.GameUiState
import com.astraldrift.app.ui.components.ArcProgressIndicator
import com.astraldrift.app.ui.theme.*
import kotlin.random.Random

@Composable
fun TrainScreen(ui: GameUiState, onSelectAction: (String) -> Unit, onSkip: () -> Unit) {
    // Stars generated once, stable across recompositions.
    val stars = remember {
        List(70) {
            Triple(
                Random.nextFloat(),
                Random.nextFloat(),
                Random.nextFloat() * 2.2f + 0.4f
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(DeepSpace)) {
        // Starfield layer
        Canvas(modifier = Modifier.fillMaxSize()) {
            stars.forEach { (xf, yf, r) ->
                drawCircle(
                    color = Starlight,
                    radius = r,
                    center = Offset(xf * size.width, yf * size.height),
                    alpha = 0.18f + r * 0.08f
                )
            }
        }

        // Nebula glow blob (top-left atmosphere)
        Box(
            modifier = Modifier
                .size(280.dp)
                .offset(x = (-60).dp, y = (-40).dp)
                .background(
                    Brush.radialGradient(
                        listOf(NebulaPurple.copy(alpha = 0.12f), Color.Transparent)
                    )
                )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
        ) {
            // Section label
            item {
                SectionLabel("TRAINING")
            }

            // Hero arc card
            item {
                GlowCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ArcProgressIndicator(
                            progress = ui.progress,
                            level = ui.level,
                            skillName = ui.skillName,
                            modifier = Modifier.size(230.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            ui.activity,
                            style = MaterialTheme.typography.titleMedium,
                            color = Starlight,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatChip("${ui.totalCompletions}", "actions")
                            StatChip("%.2fx".format(ui.proficiencyMultiplier), "speed")
                        }
                    }
                }
            }

            // Skip button
            item {
                Button(
                    onClick = onSkip,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NebulaPurple.copy(alpha = 0.3f),
                        contentColor = CeruleanGlow
                    ),
                    border = BorderStroke(1.dp, NebulaPurple.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Skip 1 Minute", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                }
            }

            // Activity switcher
            item { SectionLabel("SWITCH ACTIVITY") }

            items(ui.availableActions) { action ->
                ActionCard(action = action, onSelect = { onSelectAction(action.id) })
            }
        }
    }
}

@Composable
private fun ActionCard(action: ActionUiItem, onSelect: () -> Unit) {
    val borderBrush = if (action.isSelected)
        Brush.linearGradient(listOf(CeruleanGlow, NebulaPurple))
    else
        Brush.linearGradient(listOf(NebulaPurple.copy(0.25f), CeruleanGlow.copy(0.15f)))
    val bgAlpha = if (action.isSelected) 0.18f else 0.08f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NebulaPurple.copy(alpha = bgAlpha))
            .drawBehind {
                drawRoundRect(
                    brush = borderBrush,
                    cornerRadius = CornerRadius(12.dp.toPx()),
                    style = Stroke(width = if (action.isSelected) 1.5.dp.toPx() else 0.8.dp.toPx())
                )
            }
            .clickable(enabled = action.isUnlocked) { onSelect() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                action.display,
                color = if (action.isSelected) Starlight else StarlightMuted,
                fontWeight = if (action.isSelected) FontWeight.SemiBold else FontWeight.Normal,
                fontSize = 14.sp
            )
            Text(
                action.skillDisplay,
                color = if (action.isSelected) CeruleanGlow else StarlightMuted.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
        if (action.isSelected) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(CeruleanGlow, shape = RoundedCornerShape(4.dp))
            )
        }
    }
}

@Composable
fun GlowCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkPanel)
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(NebulaPurple.copy(0.5f), CeruleanGlow.copy(0.3f))
                    ),
                    cornerRadius = CornerRadius(20.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
            },
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        color = NebulaPurple,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        letterSpacing = 3.sp
    )
}

@Composable
private fun StatChip(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = 16.sp, color = CeruleanGlow)
        Text(label, fontSize = 10.sp, color = StarlightMuted, fontFamily = FontFamily.Monospace)
    }
}
