package com.astraldrift.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// --- Astral Drift palette ---
val DeepSpace = Color(0xFF0B1026)     // app background
val NebulaPurple = Color(0xFF6D4AFF)  // primary accent
val CeruleanGlow = Color(0xFF00B7FF)  // secondary accent / highlights
val Starlight = Color(0xFFE6F1FF)     // primary text
val DarkPanel = Color(0xFF131A38)     // cards / surfaces

// Muted starlight for secondary text (same hue, lower emphasis).
val StarlightMuted = Color(0xFF9FB2D6)

private val AstralColors = darkColorScheme(
    primary = NebulaPurple,
    onPrimary = Starlight,
    secondary = CeruleanGlow,
    onSecondary = DeepSpace,
    tertiary = CeruleanGlow,
    background = DeepSpace,
    onBackground = Starlight,
    surface = DarkPanel,
    onSurface = Starlight,
    surfaceVariant = DarkPanel,
    onSurfaceVariant = StarlightMuted,
    outline = StarlightMuted
)

/**
 * App theme. Always uses the Astral Drift dark palette (the game is a night-sky
 * setting), regardless of the system light/dark setting.
 */
@Composable
fun AstralDriftTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AstralColors,
        content = content
    )
}
