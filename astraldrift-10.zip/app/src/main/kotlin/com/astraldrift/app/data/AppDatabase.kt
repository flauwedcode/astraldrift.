package com.astraldrift.app.data

import android.content.Context
import androidx.room.*

/**
 * Persistence via Room. The whole save is one JSON blob in a single row — simple,
 * robust, and easy to evolve. As the game grows you can split hot data (inventory,
 * market cache) into their own tables; the single-row save stays the source of truth.
 */
@Entity(tableName = "save")
data class SaveEntity(
    @PrimaryKey val id: Int = 0,   // always 0 — one save slot
    val json: String,
    val updatedAt: Long
)

@Dao
interface SaveDao {
    @Query("SELECT * FROM save WHERE id = 0")
    suspend fun load(): SaveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(entity: SaveEntity)
}

@Database(entities = [SaveEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun saveDao(): SaveDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "astraldrift.db"
                ).build().also { instance = it }
            }
    }
}
