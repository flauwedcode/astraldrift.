package com.astraldrift.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.astraldrift.app.ui.GameUiState
import com.astraldrift.app.ui.SkillUiItem
import com.astraldrift.app.ui.theme.*
import com.astraldrift.engine.SkillType

@Composable
fun CharacterScreen(ui: GameUiState) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpace)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
    ) {
        item { SectionLabel("YOUR CHARACTER") }

        // Mastery profile — top 3 highest skills
        item {
            val top = ui.skills.filter { it.level > 1 }.sortedByDescending { it.level }.take(3)
            if (top.isNotEmpty()) {
                GlowCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("MASTERY PROFILE", fontSize = 9.sp, fontFamily = FontFamily.Monospace,
                            color = NebulaPurple, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            top.forEach { skill ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(skill.level.toString(), fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.ExtraBold, fontSize = 28.sp,
                                        color = CeruleanGlow)
                                    Text(skill.display.take(8), fontSize = 9.sp, color = StarlightMuted,
                                        fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Skills grouped by type
        listOf(
            SkillType.GATHERING to "GATHERING",
            SkillType.PRODUCTION to "PRODUCTION",
            SkillType.COMBAT to "COMBAT"
        ).forEach { (type, label) ->
            val group = ui.skills.filter { it.type == type }
            item { Spacer(Modifier.height(4.dp)); SectionLabel(label) }
            items(group) { skill -> SkillRow(skill) }
        }
    }
}

@Composable
private fun SkillRow(skill: SkillUiItem) {
    val animatedProgress by animateFloatAsState(
        targetValue = skill.progress,
        animationSpec = tween(600),
        label = "skill_${skill.id.name}"
    )
    val isMastered = skill.level >= 100
    val accentColor = if (isMastered) CeruleanGlow else StarlightMuted.copy(alpha = 0.5f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkPanel)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    skill.display,
                    color = if (isMastered) Starlight else StarlightMuted,
                    fontWeight = if (isMastered) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 14.sp
                )
                LevelBadge(skill.level, accentColor)
            }
            // XP progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(DeepSpace)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .fillMaxHeight()
                        .background(
                            if (isMastered)
                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    listOf(NebulaPurple, CeruleanGlow)
                                )
                            else
                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    listOf(StarlightMuted.copy(0.4f), StarlightMuted.copy(0.2f))
                                )
                        )
                )
            }
            if (isMastered) {
                Text(
                    skill.masteryHint,
                    fontSize = 10.sp,
                    color = NebulaPurple.copy(alpha = 0.9f),
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
private fun LevelBadge(level: Int, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            "Lv $level",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = color
        )
    }
}
