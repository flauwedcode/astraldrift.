package com.astraldrift.server

import com.astraldrift.engine.*

/**
 * Anti-cheat / validation. Core principle: the client is untrusted. Anything the
 * client reports (progress, eligibility, balances) is re-derived or bounded here.
 */
object AntiCheat {

    /**
     * Absolute upper bound on XP/second for a single skill: the calibrated base
     * rate at maximum proficiency and full external boosts, times a safety margin
     * to avoid false positives from rounding/burst catch-up. Anything above this
     * is physically impossible and indicates tampering.
     */
    val maxPlausibleXpPerSecond: Double =
        Progression.BASE_XP_PER_SECOND *
            Mastery.actionSpeedMultiplier(XpCurve.MAX_LEVEL) *
            Progression.fullExternalMultiplier() *
            3.0  // safety margin

    data class Violation(val code: String, val detail: String)

    /**
     * Compare two snapshots taken [elapsedMs] apart and flag impossible jumps:
     * XP that decreased, or XP gained faster than the hard ceiling allows.
     */
    fun validateProgress(old: PlayerSnapshot, new: PlayerSnapshot, elapsedMs: Long): List<Violation> {
        val out = mutableListOf<Violation>()
        val seconds = (elapsedMs / 1000.0).coerceAtLeast(0.0)
        val cap = (maxPlausibleXpPerSecond * seconds).toLong()
        val oldBySkill = old.skills.associate { it.id to it.xp }

        for (snap in new.skills) {
            val before = oldBySkill[snap.id] ?: 0L
            val delta = snap.xp - before
            if (delta < 0) out += Violation("XP_DECREASED", "${snap.id}: $before -> ${snap.xp}")
            else if (delta > cap) out += Violation(
                "XP_RATE_IMPOSSIBLE",
                "${snap.id}: +$delta in ${elapsedMs}ms (cap $cap)"
            )
        }
        return out
    }

    /** Re-derive apex eligibility server-side rather than trusting the client. */
    fun verifyApexEligibility(player: Player, monster: Monster): ApexGating.GateCheck {
        val gate = monster.gate
            ?: return ApexGating.GateCheck(true, emptyList())
        return ApexGating.checkPlayer(player, gate)
    }

    /** Basic account-integrity checks run on save. */
    fun validateAccount(p: Player): List<Violation> {
        val out = mutableListOf<Violation>()
        if (p.shards < 0) out += Violation("NEGATIVE_SHARDS", "${p.shards}")
        if (p.essence.balance < 0) out += Violation("NEGATIVE_ESSENCE", "${p.essence.balance}")
        if (p.currentHp < 0 || p.currentHp > p.maxHp + 1e-6)
            out += Violation("HP_OUT_OF_RANGE", "${p.currentHp}/${p.maxHp}")
        p.skills.values.forEach {
            if (it.xp < 0) out += Violation("NEGATIVE_XP", it.id.name)
            if (it.level > XpCurve.MAX_LEVEL) out += Violation("LEVEL_OVER_CAP", it.id.name)
        }
        // Equipped items must exist in the catalogue (no client-fabricated gear).
        p.equipment.values.forEach {
            if (ItemCatalogue.resolve(it.id) == null)
                out += Violation("UNKNOWN_ITEM_EQUIPPED", it.id)
        }
        return out
    }
}
