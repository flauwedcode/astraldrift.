package com.astraldrift.server

import com.astraldrift.engine.*
import kotlinx.serialization.Serializable

/**
 * Persistence layer. A [PlayerSnapshot] is the durable, serializable form of a
 * Player. These are @Serializable so kotlinx.serialization persists them directly
 * (the Android client stores the JSON in Room; a server would store it in
 * Postgres). Inventory/equipment store item *ids*, resolved via ItemCatalogue.
 */

@Serializable
data class SkillSnapshot(val id: String, val xp: Long)

@Serializable
data class StackSnapshot(val itemId: String, val quantity: Int)

@Serializable
data class PlayerSnapshot(
    val id: String,
    val name: String,
    val shards: Long,
    val essenceBalance: Double,
    val essenceLastAccrualEpochMs: Long,
    val essenceResonance: Double,
    val currentHp: Double,
    val maxHp: Double,
    val skills: List<SkillSnapshot>,
    val inventory: List<StackSnapshot>,
    val equipment: Map<String, String>,   // EquipSlot name -> item id
    val openedDoors: Set<String>
)

object PlayerCodec {

    fun toSnapshot(p: Player): PlayerSnapshot = PlayerSnapshot(
        id = p.id,
        name = p.name,
        shards = p.shards,
        essenceBalance = p.essence.balance,
        essenceLastAccrualEpochMs = p.essence.lastAccrualEpochMs,
        essenceResonance = p.essence.resonanceSnapshot,
        currentHp = p.currentHp,
        maxHp = p.maxHp,
        skills = p.skills.values.map { SkillSnapshot(it.id.name, it.xp) },
        inventory = p.inventory.map { StackSnapshot(it.item.id, it.quantity) },
        equipment = p.equipment.entries.associate { (slot, item) -> slot.name to item.id },
        openedDoors = p.openedDoors.toSet()
    )

    fun fromSnapshot(s: PlayerSnapshot): Player {
        val p = Player(id = s.id, name = s.name)
        p.shards = s.shards
        p.essence.balance = s.essenceBalance
        p.essence.lastAccrualEpochMs = s.essenceLastAccrualEpochMs
        p.essence.resonanceSnapshot = s.essenceResonance
        p.currentHp = s.currentHp
        p.maxHp = s.maxHp

        s.skills.forEach { snap ->
            val id = SkillId.valueOf(snap.id)
            p.skills[id] = SkillProgress(id, snap.xp)
        }
        s.inventory.forEach { st -> p.addItem(ItemCatalogue.require(st.itemId), st.quantity) }
        s.equipment.forEach { (slotName, itemId) ->
            p.equipment[EquipSlot.valueOf(slotName)] = ItemCatalogue.require(itemId)
        }
        p.openedDoors.addAll(s.openedDoors)
        return p
    }
}
