package com.astraldrift.server

import com.astraldrift.engine.Item
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * A market / auction house. Listed items are held in ESCROW (removed from the
 * seller immediately), so they can't be sold here and traded elsewhere at the same
 * time — the classic market dupe. Buyers pay shards; the house takes a fee.
 */
class MarketService(private val repo: PlayerRepository, private val feeRate: Double = 0.05) {

    data class Listing(
        val id: String,
        val sellerId: String,
        val item: Item,          // escrowed definition
        var quantity: Int,       // remaining units
        val pricePerUnit: Long
    )

    private val listings = ConcurrentHashMap<String, Listing>()

    sealed class ListResult {
        data class Listed(val listingId: String) : ListResult()
        data class Rejected(val reason: String) : ListResult()
    }

    sealed class BuyResult {
        data class Bought(val quantity: Int, val totalPaid: Long) : BuyResult()
        data class Rejected(val reason: String) : BuyResult()
    }

    fun list(sellerId: String, itemId: String, quantity: Int, pricePerUnit: Long): ListResult {
        if (quantity <= 0 || pricePerUnit <= 0) return ListResult.Rejected("invalid quantity/price")
        synchronized(repo) {
            val seller = repo.get(sellerId) ?: return ListResult.Rejected("unknown seller")
            val def = seller.inventory.firstOrNull { it.item.id == itemId }?.item
                ?: return ListResult.Rejected("seller does not hold $itemId")
            if (def.isUntradeable) return ListResult.Rejected("${def.name} cannot be listed")
            if (!seller.hasItem(itemId, quantity)) return ListResult.Rejected("not enough $itemId")

            // Escrow: pull the items out of the seller now.
            check(seller.removeItem(itemId, quantity)) { "race removing escrow" }
            repo.save(seller)

            val id = UUID.randomUUID().toString()
            listings[id] = Listing(id, sellerId, def, quantity, pricePerUnit)
            return ListResult.Listed(id)
        }
    }

    fun buy(buyerId: String, listingId: String, quantity: Int): BuyResult {
        if (quantity <= 0) return BuyResult.Rejected("invalid quantity")
        synchronized(repo) {
            val listing = listings[listingId] ?: return BuyResult.Rejected("listing not found")
            if (listing.sellerId == buyerId) return BuyResult.Rejected("cannot buy your own listing")
            if (quantity > listing.quantity) return BuyResult.Rejected("only ${listing.quantity} available")

            val buyer = repo.get(buyerId) ?: return BuyResult.Rejected("unknown buyer")
            val total = listing.pricePerUnit * quantity
            if (buyer.shards < total) return BuyResult.Rejected("insufficient shards")

            val seller = repo.get(listing.sellerId)
                ?: return BuyResult.Rejected("seller account missing")

            // Move shards (minus fee) to seller, items to buyer.
            val fee = (total * feeRate).toLong()
            buyer.shards -= total
            seller.shards += (total - fee)
            buyer.addItem(listing.item, quantity)

            listing.quantity -= quantity
            if (listing.quantity == 0) listings.remove(listingId)

            repo.save(buyer)
            repo.save(seller)
            return BuyResult.Bought(quantity, total)
        }
    }

    /** Cancel a listing and return the escrowed remainder to the seller. */
    fun cancel(sellerId: String, listingId: String): Boolean {
        synchronized(repo) {
            val listing = listings[listingId] ?: return false
            if (listing.sellerId != sellerId) return false
            val seller = repo.get(sellerId) ?: return false
            seller.addItem(listing.item, listing.quantity)
            repo.save(seller)
            listings.remove(listingId)
            return true
        }
    }

    fun open(): List<Listing> = listings.values.sortedBy { it.pricePerUnit }
}
