package com.astraldrift.server

import com.astraldrift.engine.Item
import com.astraldrift.engine.Player

/**
 * Direct player-to-player trading.
 *
 * Threat model this guards against:
 *  • DUPING: validate ownership at execution time, then remove-then-add inside a
 *    single critical section, saving both players together. Either the whole swap
 *    commits or nothing does.
 *  • UNTRADEABLE LEAKS: the Master Wand, world-power artifacts, and character-bound
 *    rewards carry tradeable=false and are rejected before any mutation.
 *  • PHANTOM ITEMS/SHARDS: each side is checked against its *own* live inventory and
 *    shard balance, not against client-supplied claims.
 *
 * Concurrency note: uses a coarse lock on the shared repository. A production,
 * multi-process deployment replaces this with a database transaction (row locks on
 * both player rows) — the validate→mutate→commit shape stays identical.
 */
class TradeService(private val repo: PlayerRepository) {

    data class Offer(
        val playerId: String,
        val items: List<Pair<String, Int>> = emptyList(), // (itemId, quantity)
        val shards: Long = 0L
    )

    sealed class Result {
        object Success : Result()
        data class Rejected(val reason: String) : Result()
    }

    fun execute(a: Offer, b: Offer): Result {
        synchronized(repo) {
            val pa = repo.get(a.playerId) ?: return Result.Rejected("unknown player ${a.playerId}")
            val pb = repo.get(b.playerId) ?: return Result.Rejected("unknown player ${b.playerId}")
            if (pa.id == pb.id) return Result.Rejected("cannot trade with self")

            // Validate both offers against live state. Capture the exact Item defs to move.
            val aItems = resolveOffer(pa, a) ?: return Result.Rejected("${pa.name}: missing/untradeable items")
            val bItems = resolveOffer(pb, b) ?: return Result.Rejected("${pb.name}: missing/untradeable items")
            if (pa.shards < a.shards) return Result.Rejected("${pa.name}: insufficient shards")
            if (pb.shards < b.shards) return Result.Rejected("${pb.name}: insufficient shards")

            // Commit: remove from each, then grant to the other. Shards swap too.
            a.items.forEach { (id, q) -> check(pa.removeItem(id, q)) { "race: ${pa.name} lost $id" } }
            b.items.forEach { (id, q) -> check(pb.removeItem(id, q)) { "race: ${pb.name} lost $id" } }

            aItems.forEach { (item, q) -> pb.addItem(item, q) }
            bItems.forEach { (item, q) -> pa.addItem(item, q) }

            pa.shards = pa.shards - a.shards + b.shards
            pb.shards = pb.shards - b.shards + a.shards

            repo.save(pa)
            repo.save(pb)
            return Result.Success
        }
    }

    /**
     * Confirm the player owns every offered stack and that each item is tradeable.
     * Returns the resolved (Item, qty) list to grant the counterparty, or null.
     */
    private fun resolveOffer(p: Player, offer: Offer): List<Pair<Item, Int>>? {
        // Aggregate requested quantities per id (a player might list an id twice).
        val needed = offer.items.groupBy({ it.first }, { it.second })
            .mapValues { it.value.sum() }
        val resolved = mutableListOf<Pair<Item, Int>>()
        for ((id, qty) in needed) {
            if (qty <= 0) return null
            if (!p.hasItem(id, qty)) return null
            val def = p.inventory.firstOrNull { it.item.id == id }?.item ?: return null
            if (def.isUntradeable) return null
            resolved += def to qty
        }
        return resolved
    }
}
