package com.astraldrift.server

import com.astraldrift.engine.*

/**
 * Authoritative registry mapping item id -> definition. Saved inventories store
 * only ids; this rebuilds them on load. In production this is generated from the
 * same content source the client ships, guaranteeing client/server agree on what
 * every item is and whether it's tradeable.
 */
object ItemCatalogue {

    private val byId = mutableMapOf<String, Item>()

    init {
        // Content registered at boot. Extend as the game grows.
        DropTables.allMaterials.forEach(::register)
        CelestialWeapons.all.forEach(::register)
        register(WorldPowers.STAFF_OF_THE_TURNING.artifactItem)
        register(GatedDoors.HUSHED_VAULT.reward)

        // Door keys (simple content items referenced by GatedDoors requirements).
        register(Item("key_void", "Void Key", Rarity.RARE))
        register(Item("key_ember", "Ember Key", Rarity.RARE))
    }

    fun register(item: Item) { byId[item.id] = item }

    fun resolve(id: String): Item? = byId[id]

    /** Resolve or fail loudly — saved data referencing an unknown item is a bug. */
    fun require(id: String): Item =
        byId[id] ?: error("Item id not in catalogue: $id (register its definition)")

    fun knownIds(): Set<String> = byId.keys.toSet()
}
