package com.astraldrift.server

import com.astraldrift.engine.*

/**
 * Pure-Kotlin, in-memory demonstration of the authoritative backend. No network,
 * no database — it wires the real services to an in-memory repository so the LOGIC
 * (atomic trades, escrowed market, server-clock essence, anti-cheat) is exercised
 * and reviewable. Run: set mainClass to com.astraldrift.server.ServerDemoKt.
 */
fun main() {
    println("=== ASTRAL DRIFT — backend demo (in-memory) ===\n")

    val repo = InMemoryPlayerRepository()
    val essence = EssenceService(repo)
    val trade = TradeService(repo)
    val market = MarketService(repo)

    val stardust = ItemCatalogue.require("mat_stardust")
    val voidShard = ItemCatalogue.require("mat_void_shard")

    // Create two accounts.
    val a = Player(name = "Ada").apply { addItem(stardust, 300); shards = 1_000 }
    val b = Player(name = "Bram").apply { addItem(voidShard, 80); shards = 2_000 }
    repo.create(a); repo.create(b)
    println("Created Ada (300 stardust, 1000 shards) and Bram (80 void shard, 2000 shards)\n")

    // 1. ESSENCE — Ada was away 3 years; server banks it from its own clock.
    val now = System.currentTimeMillis()
    repo.get(a.id)!!.also { it.essence.lastAccrualEpochMs = now - 3L*365*24*60*60*1000; repo.save(it) }
    val earned = essence.claimOnLogin(a.id, now)
    println("1) Ada logs in after 3 years → banked ${"%,.0f".format(earned)} Essence (server-computed)\n")

    // 2. TRADE — Ada: 100 stardust + 500 shards  ⇄  Bram: 50 void shard.
    val tr = trade.execute(
        TradeService.Offer(a.id, items = listOf("mat_stardust" to 100), shards = 500),
        TradeService.Offer(b.id, items = listOf("mat_void_shard" to 50))
    )
    println("2) Trade result: ${tr::class.simpleName}")
    repo.get(a.id)!!.let { println("   Ada:  ${inv(it)} | ${it.shards} shards") }
    repo.get(b.id)!!.let { println("   Bram: ${inv(it)} | ${it.shards} shards") }
    println()

    // 3. UNTRADEABLE — give Ada the Master Wand, then try to trade it. Must reject.
    repo.get(a.id)!!.also { it.addItem(CelestialWeapons.MASTER_WAND); repo.save(it) }
    val tr2 = trade.execute(
        TradeService.Offer(a.id, items = listOf(CelestialWeapons.MASTER_WAND.id to 1)),
        TradeService.Offer(b.id, shards = 1)
    )
    println("3) Trade the untradeable Master Wand → ${tr2::class.simpleName}: " +
            "${(tr2 as? TradeService.Result.Rejected)?.reason}\n")

    // 4. MARKET — Ada lists 200 stardust @2 shards; Bram buys 100.
    val listed = market.list(a.id, "mat_stardust", 200, pricePerUnit = 2)
    val listingId = (listed as MarketService.ListResult.Listed).listingId
    val bought = market.buy(b.id, listingId, 100)
    println("4) Market: list 200 stardust @2 → ${bought}")
    repo.get(a.id)!!.let { println("   Ada shards after sale (5% fee): ${it.shards}") }
    repo.get(b.id)!!.let { println("   Bram: ${inv(it)} | ${it.shards} shards") }
    println("   Open listings: ${market.open().map { "${it.quantity}x ${it.item.name} @${it.pricePerUnit}" }}\n")

    // 5. ANTI-CHEAT — impossible XP jump, apex gate recheck, account sanity.
    val before = PlayerCodec.toSnapshot(repo.get(a.id)!!)
    val tampered = before.copy(skills = before.skills.map {
        if (it.id == SkillId.STARDIVING.name) it.copy(xp = it.xp + 1_000_000_000L) else it
    })
    val violations = AntiCheat.validateProgress(before, tampered, elapsedMs = 60_000)
    println("5) Anti-cheat:")
    println("   impossible XP jump → ${violations.map { it.code }}")

    val freshLowbie = Player(name = "Lowbie")
    val gate = AntiCheat.verifyApexEligibility(freshLowbie, Monsters.THE_DEVOURER_OF_QUIET)
    println("   level-1 vs apex boss → passed=${gate.passed}, ${gate.reasons.size} requirements unmet")

    val tamperedAcct = Player(name = "Cheat").apply { shards = -50 }
    println("   negative-shards account → ${AntiCheat.validateAccount(tamperedAcct).map { it.code }}\n")

    // 6. PERSISTENCE — prove a full save/load round-trip via the repository.
    val reloaded = repo.get(a.id)!!
    println("6) Persistence round-trip for Ada:")
    println("   ${reloaded.inventory.size} inventory stacks, ${reloaded.shards} shards, " +
            "Essence ${"%,.0f".format(reloaded.essence.balance)} — reconstructed from snapshot")
}

private fun inv(p: Player): String =
    p.inventory.joinToString { "${it.quantity}x ${it.item.name}" }.ifEmpty { "(empty)" }
