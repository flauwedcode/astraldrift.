package com.astraldrift.server

import com.astraldrift.engine.EssenceSpending
import com.astraldrift.engine.Player
import com.astraldrift.engine.SkillId

/**
 * Server-authoritative Idle Essence. The whole security model rests on one rule:
 * the SERVER computes accrual from the stored timestamp to the server's own clock.
 * The client never sends "I was away X ms" — that would be trivially forgeable.
 */
class EssenceService(private val repo: PlayerRepository) {

    /** Call on login: bank everything earned since the player last logged out. */
    fun claimOnLogin(playerId: String, nowMs: Long = System.currentTimeMillis()): Double {
        synchronized(repo) {
            val p = repo.get(playerId) ?: return 0.0
            val earned = p.essence.accrue(nowMs)   // server clock = source of truth
            repo.save(p)
            return earned
        }
    }

    /**
     * Call on logout: snapshot resonance (so offline rate reflects worn gear) and
     * bank up to the moment of logout, freezing the clock until next login.
     */
    fun onLogout(playerId: String, nowMs: Long = System.currentTimeMillis()) {
        synchronized(repo) {
            val p = repo.get(playerId) ?: return
            p.essence.accrue(nowMs)
            p.essence.snapshotResonance(p)
            repo.save(p)
        }
    }

    /** Spend Essence into a skill (engine enforces non-combat + level-500 ceiling). */
    fun spend(playerId: String, skill: SkillId, amount: Double): EssenceSpending.SpendResult {
        synchronized(repo) {
            val p = repo.get(playerId)
                ?: return EssenceSpending.SpendResult.NoEssence
            val result = EssenceSpending.spend(p, skill, amount)
            repo.save(p)
            return result
        }
    }

    fun balance(playerId: String): Double =
        repo.get(playerId)?.essence?.balance ?: 0.0
}
