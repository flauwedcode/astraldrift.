package com.astraldrift.server

import com.astraldrift.engine.Player
import java.util.concurrent.ConcurrentHashMap

/**
 * Storage abstraction. The in-memory impl is for tests/local dev; a production
 * deployment swaps in a Postgres-backed implementation (snapshots serialized via
 * PlayerCodec) plus a Redis cache for hot players. The interface is what the
 * services depend on, so nothing above this layer changes when you swap stores.
 */
interface PlayerRepository {
    fun get(playerId: String): Player?
    fun save(player: Player)
    fun create(player: Player): Player
    fun exists(playerId: String): Boolean
}

class InMemoryPlayerRepository : PlayerRepository {
    // Stored as snapshots to mimic a real datastore round-trip (no shared mutable
    // references leaking across callers — every get() reconstructs a fresh Player).
    private val store = ConcurrentHashMap<String, PlayerSnapshot>()

    override fun get(playerId: String): Player? =
        store[playerId]?.let(PlayerCodec::fromSnapshot)

    override fun save(player: Player) {
        store[player.id] = PlayerCodec.toSnapshot(player)
    }

    override fun create(player: Player): Player {
        require(!store.containsKey(player.id)) { "Player already exists: ${player.id}" }
        save(player)
        return player
    }

    override fun exists(playerId: String): Boolean = store.containsKey(playerId)
}
