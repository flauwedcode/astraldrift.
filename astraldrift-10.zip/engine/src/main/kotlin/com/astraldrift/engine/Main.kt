package com.astraldrift.engine

import kotlin.random.Random

/**
 * Standalone demo so you can watch the engine work before any Android UI
 * exists. Run on plain JVM:  kotlinc src -include-runtime -d game.jar && java -jar game.jar
 */
fun main() {
    println("=== ASTRAL DRIFT — engine demo ===\n")

    val engine = GameEngine(rng = Random(42))
    val player = Player(name = "Wanderer")

    // 1. Idle a combat action for a simulated 2 minutes.
    val hunt = Skills.actions.first { it.id == "hunt_wretch" }
    val state = GameEngine.ActionState(hunt)
    val report = engine.tick(player, state, deltaMs = 2 * 60 * 1000L)
    println("Hunted '${hunt.display}' for 2 min:")
    println("  completions = ${report.completions}, xp = ${report.xpGained}")
    println("  Melee level = ${player.skill(SkillId.MELEE).level}")
    println("  drops = ${report.drops.joinToString { "${it.quantity}x ${it.item.name}" }}\n")

    // 2. Force-grant the celestial set + master wand to show synergy resolution.
    listOf(
        CelestialWeapons.MASTER_WAND,
        CelestialWeapons.TIDECALLER_GLAIVE,   // note: only one main-hand can be equipped at a time
        CelestialWeapons.EMBERVEIL_FOCUS,
        CelestialWeapons.LANTERN_OF_QUIET_STARS
    ).forEach { player.addItem(it); }

    // Equip a coherent loadout (wand main-hand, focus off-hand swapped to relic-style demo).
    player.equip(CelestialWeapons.MASTER_WAND)
    player.equip(CelestialWeapons.EMBERVEIL_FOCUS)
    player.equip(CelestialWeapons.LANTERN_OF_QUIET_STARS)

    println("Equipped loadout. Active hidden synergies:")
    SynergyRegistry.activeNames(player).forEach { println("  • $it") }
    println("Effective POWER = ${player.effectiveStats()[Stat.POWER]}")
    println("Effective LUCK  = ${player.effectiveStats()[Stat.LUCK]}\n")

    // 3. Secret door: give the keys + echoes, then open the Hushed Vault once.
    player.addItem(Item("key_void", "Void Key", Rarity.RARE))
    player.addItem(Item("key_ember", "Ember Key", Rarity.RARE))
    player.addItem(Item("mat_faint_echo", "Faint Echo", Rarity.UNCOMMON, stackable = true), 3)

    when (val r = GatedDoors.attemptOpen(player, GatedDoors.HUSHED_VAULT.id)) {
        is GatedDoors.OpenResult.Success ->
            println("Opened Hushed Vault → ${r.reward.item.name} (untradeable=${r.reward.item.isUntradeable})")
        GatedDoors.OpenResult.AlreadyOpened -> println("Vault already opened.")
        GatedDoors.OpenResult.MissingRequirements -> println("Missing requirements.")
    }
    // Second attempt proves it's one-time.
    println("Re-attempt: ${GatedDoors.attemptOpen(player, GatedDoors.HUSHED_VAULT.id)::class.simpleName}\n")

    // 4. World power: hold the staff, pass it, activate it.
    val ledger = WorldPowerLedger()
    ledger.pass(WorldPowers.STAFF_OF_THE_TURNING.id, player.id)
    val act = ledger.activate(WorldPowers.STAFF_OF_THE_TURNING, player.id, nowMs = System.currentTimeMillis())
    println("Staff activation: ${act::class.simpleName}\n")

    // 5. Apex gate: show the under-geared player being correctly rejected.
    val check = ApexGating.checkParty(listOf(player), Monsters.THE_DEVOURER_OF_QUIET)
    println("Apex gate vs '${Monsters.THE_DEVOURER_OF_QUIET.name}':")
    check.forEach { (who, c) ->
        println("  $who → ${if (c.passed) "PASS" else "FAIL: ${c.reasons.joinToString()}"}")
    }
    println()

    // 6. THE 3-YEAR TEST — make an account, "leave" for 3 years, come back.
    println("=== Idle Essence: the 3-year test ===")
    // Snapshot resonance from currently-equipped gear (drives offline rate).
    player.essence.snapshotResonance(player)
    println("Offline resonance snapshot = ${player.essence.resonanceSnapshot} " +
            "(rate ×${"%.2f".format(1 + player.essence.resonanceSnapshot / 100.0)})")

    // Pretend the last accrual was 3 years ago, then log in now.
    val threeYearsMs = 3L * 365 * 24 * 60 * 60 * 1000
    val now = System.currentTimeMillis()
    player.essence.lastAccrualEpochMs = now - threeYearsMs
    val earned = player.essence.accrue(now)
    println("Welcome back. Banked over 3 years: ${"%,.0f".format(earned)} Essence")
    println("Pool balance: ${"%,.0f".format(player.essence.balance)}\n")

    // Pour it into a NON-COMBAT skill — lifts it toward the halfway ceiling (lvl 500).
    val before = player.skill(SkillId.STARDIVING).level
    when (val r = EssenceSpending.spendToCeiling(player, SkillId.STARDIVING)) {
        is EssenceSpending.SpendResult.Success ->
            println("Spent on Stardiving: lvl $before → ${player.skill(SkillId.STARDIVING).level} " +
                    "(ceiling ${EssenceConfig.CEILING_LEVEL}); " +
                    "${"%,.0f".format(r.essenceSpent)} used, " +
                    "${"%,.0f".format(player.essence.balance)} left in pool")
        else -> println("Stardiving spend: ${r::class.simpleName}")
    }

    // Try to dump Essence into a COMBAT skill — must be refused (apex protection).
    val combat = EssenceSpending.spend(player, SkillId.MELEE, 1_000_000.0)
    println("Spend on Melee (combat): ${combat::class.simpleName}  ← blocked by design\n")

    // 7. PROGRESSION: level cap, proficiency ramp, and time-to-max.
    println("=== Progression: cap 1000, proficiency, time-to-max ===")
    println("Skill cap = ${XpCurve.MAX_LEVEL}, total XP to max = ${"%,d".format(XpCurve.totalXpToMax)}")
    listOf(1, 100, 500, 1000).forEach { lvl ->
        println("  Proficiency @ lvl $lvl = ${"%.2f".format(Mastery.actionSpeedMultiplier(lvl))}x speed")
    }
    println("Solo time to max one skill    : ${"%.1f".format(Progression.soloYearsToMax())} years")
    println("With gear+guild+teamwork (+%.0f%%): %.1f years"
        .format((Progression.fullExternalMultiplier() - 1) * 100, Progression.boostedYearsToMax()))
    println()

    // 8. CHARACTER MASTERY: unique passive bonuses from what you train.
    println("=== Character mastery profile ===")
    val veteran = Player(name = "Old-Drifter")
    veteran.skill(SkillId.STARDIVING).addXp(XpCurve.totalXpToMax)        // a maxed gatherer
    veteran.skill(SkillId.ASTRALSMITH).addXp(XpCurve.xpForLevel(600))    // strong smith
    println("Profile: ${Mastery.profile(veteran).joinToString()}")
    val vs = veteran.effectiveStats()
    println("  Effective LUCK (mastery)         = ${"%.0f".format(vs[Stat.LUCK] ?: 0.0)}")
    println("  Effective GATHER_SPEED (mastery) = ${"%.0f".format(vs[Stat.GATHER_SPEED] ?: 0.0)}%")
    println("  Effective POWER (mastery)        = ${"%.0f".format(vs[Stat.POWER] ?: 0.0)}\n")

    println("--- Codex sample ---")
    println(Lore.DRIFTERS.lineSequence().take(3).joinToString("\n"))
}
