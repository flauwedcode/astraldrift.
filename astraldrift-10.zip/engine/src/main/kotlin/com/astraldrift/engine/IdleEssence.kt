package com.astraldrift.engine

/**
 * IDLE ESSENCE — the "never lose progress" system.
 *
 * Core promise: an account accrues Essence in real time, FOREVER, with NO cap
 * on accrual. Logging in daily and logging in once every three years bank the
 * exact same total. You are never punished for being away.
 *
 * Guardrails that keep this from breaking the game:
 *  1. Essence is a SPENDABLE CURRENCY (global pool), not auto-applied XP. The
 *     player chooses where it goes.
 *  2. PER-SKILL CEILING: Essence can lift any eligible skill only up to its
 *     halfway point (level 100 of 200). Past halfway you must actually play.
 *  3. NON-COMBAT ONLY: combat skills can never receive Essence, so a returning
 *     account can't instantly satisfy apex-boss gates. (See ApexGating.)
 *  4. GEAR-BOOSTED ACCRUAL: offline Rift Resonance increases the rate, snapshot
 *     at logout so the bonus reflects the gear worn during the away period.
 */
object EssenceConfig {
    /** Base accrual: 10 Essence per real minute. Tunable. */
    const val BASE_ESSENCE_PER_MS: Double = 10.0 / 60_000.0

    /** Each point of (offline) Rift Resonance adds this % to the accrual rate. */
    const val RESONANCE_PERCENT_PER_POINT: Double = 1.0

    /** Essence may raise an eligible skill up to (and including) this level. */
    const val CEILING_LEVEL: Int = XpCurve.MAX_LEVEL / 2   // 100 of 200

    /** Essence-to-XP conversion. 1:1 by default; tune for economy pacing. */
    const val ESSENCE_PER_XP: Double = 1.0

    fun ceilingXp(): Long = XpCurve.xpForLevel(CEILING_LEVEL)

    /** Combat skills are NEVER eligible — this is the apex-gating protection. */
    fun isEligible(skill: SkillId): Boolean = skill.type != SkillType.COMBAT
}

/**
 * Per-account Essence ledger. Accrual is pure wall-clock time × rate; nothing
 * about it depends on the player having selected an action, which is what makes
 * "log in 3 years later and still have it" work.
 */
class EssenceAccount(
    var balance: Double = 0.0,
    var lastAccrualEpochMs: Long = System.currentTimeMillis(),
    /** Resonance used for accrual while away. Set via [snapshotResonance] at logout. */
    var resonanceSnapshot: Double = 0.0
) {
    fun currentRatePerMs(): Double =
        EssenceConfig.BASE_ESSENCE_PER_MS *
            (1.0 + resonanceSnapshot * EssenceConfig.RESONANCE_PERCENT_PER_POINT / 100.0)

    /**
     * Bank all Essence earned since the last accrual up to [nowMs]. No cap.
     * Call this on login and at logout. Returns the amount earned.
     */
    fun accrue(nowMs: Long): Double {
        val elapsed = (nowMs - lastAccrualEpochMs).coerceAtLeast(0L)
        val earned = elapsed * currentRatePerMs()
        balance += earned
        lastAccrualEpochMs = nowMs
        return earned
    }

    /** Snapshot the player's effective Rift Resonance to drive offline accrual. */
    fun snapshotResonance(player: Player) {
        resonanceSnapshot = player.effectiveStats()[Stat.RIFT_RESONANCE] ?: 0.0
    }

    /** Human-readable estimate, e.g. for a "you were away 412 days" summary. */
    fun projectedBalanceAfter(nowMs: Long): Double {
        val elapsed = (nowMs - lastAccrualEpochMs).coerceAtLeast(0L)
        return balance + elapsed * currentRatePerMs()
    }
}

object EssenceSpending {

    sealed class SpendResult {
        data class Success(
            val skill: SkillId,
            val essenceSpent: Double,
            val xpApplied: Long,
            val levelUp: LevelUpResult,
            /** Essence requested but not needed (skill hit ceiling). Stays in pool. */
            val essenceUnused: Double
        ) : SpendResult()

        /** Combat skills are never eligible. */
        object CombatSkillBlocked : SpendResult()

        /** Skill is already at or past the halfway ceiling. */
        object SkillAtCeiling : SpendResult()

        /** Pool is empty. */
        object NoEssence : SpendResult()
    }

    /**
     * Spend up to [essenceRequested] from the pool into [skill]. Clamped by:
     *  - eligibility (non-combat only),
     *  - the skill's remaining room below the ceiling,
     *  - the available balance.
     * Any requested-but-unneeded Essence simply stays in the pool.
     */
    fun spend(player: Player, skill: SkillId, essenceRequested: Double): SpendResult {
        if (!EssenceConfig.isEligible(skill)) return SpendResult.CombatSkillBlocked

        val account = player.essence
        if (account.balance <= 0.0 || essenceRequested <= 0.0) return SpendResult.NoEssence

        val progress = player.skill(skill)
        val ceiling = EssenceConfig.ceilingXp()
        if (progress.xp >= ceiling) return SpendResult.SkillAtCeiling

        val spendable = minOf(essenceRequested, account.balance)
        val xpRoom = ceiling - progress.xp
        val xpFromSpendable = (spendable / EssenceConfig.ESSENCE_PER_XP).toLong()
        val xpToApply = minOf(xpRoom, xpFromSpendable)

        val essenceUsed = xpToApply * EssenceConfig.ESSENCE_PER_XP
        account.balance -= essenceUsed
        val lvl = progress.addXp(xpToApply)

        return SpendResult.Success(
            skill = skill,
            essenceSpent = essenceUsed,
            xpApplied = xpToApply,
            levelUp = lvl,
            essenceUnused = essenceRequested - essenceUsed
        )
    }

    /** Convenience: pour Essence into a skill until it hits the ceiling or the pool empties. */
    fun spendToCeiling(player: Player, skill: SkillId): SpendResult =
        spend(player, skill, player.essence.balance)

    /**
     * Non-mutating preview: what level would [skill] reach if [essence] were
     * applied now? Useful for "drag a slider" UI. Returns current level if the
     * skill is ineligible or already capped.
     */
    fun previewLevel(player: Player, skill: SkillId, essence: Double): Int {
        if (!EssenceConfig.isEligible(skill)) return player.skill(skill).level
        val ceiling = EssenceConfig.ceilingXp()
        val cur = player.skill(skill).xp
        if (cur >= ceiling) return EssenceConfig.CEILING_LEVEL
        val xpFrom = (essence / EssenceConfig.ESSENCE_PER_XP).toLong()
        val projected = minOf(ceiling, cur + xpFrom)
        return XpCurve.levelForXp(projected)
    }
}
