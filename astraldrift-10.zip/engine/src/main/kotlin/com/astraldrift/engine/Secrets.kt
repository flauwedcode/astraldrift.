package com.astraldrift.engine

/**
 * Secrets layer.
 *
 *  1. GatedDoors  — possessing a specific combination of items unlocks a
 *                   one-time vault granting a unique reward. Tracked per player
 *                   so it can never be farmed twice.
 *
 *  2. WorldPowers — rare artifacts (e.g. a staff) that grant server-affecting
 *                   abilities and can be PASSED between players. Ownership is
 *                   global and singular: only one holder at a time.
 */

// ---- 1. Inventory-gated one-time doors ------------------------------------

data class GatedDoor(
    val id: String,
    val name: String,
    /** Item IDs (and quantities) the player must possess to open the door. */
    val requiredItems: Map<String, Int>,
    /** Whether the required items are consumed on opening. */
    val consumesItems: Boolean,
    val reward: Item,
    val rewardQty: Int = 1,
    val hint: String = ""
)

object GatedDoors {

    // Example: holding two specific keys + an echo opens the Hushed Vault,
    // which grants a character-bound relic exactly once.
    val HUSHED_VAULT = GatedDoor(
        id = "door_hushed_vault",
        name = "The Hushed Vault",
        requiredItems = mapOf(
            "key_void" to 1,
            "key_ember" to 1,
            "mat_faint_echo" to 3
        ),
        consumesItems = true,
        reward = Item(
            id = "secret_vault_sigil",
            name = "Sigil of the Hushed Vault",
            rarity = Rarity.MYTHIC,
            slot = EquipSlot.AMULET,
            tradeable = false,
            visibleStats = listOf(StatMod(Stat.RIFT_RESONANCE, flat = 25.0)),
            hiddenStats = listOf(StatMod(Stat.LUCK, percent = 35.0), StatMod(Stat.XP_GAIN, percent = 20.0)),
            synergyTags = setOf("celestial_drift"),
            flags = setOf("character_bound"),
            flavor = "The door remembers you now."
        ),
        hint = "Two keys and the echoes of three forgotten things."
    )

    private val all = listOf(HUSHED_VAULT)
    fun byId(id: String) = all.find { it.id == id }
    fun list() = all

    sealed class OpenResult {
        data class Success(val reward: ItemStack) : OpenResult()
        object AlreadyOpened : OpenResult()
        object MissingRequirements : OpenResult()
    }

    fun attemptOpen(player: Player, doorId: String): OpenResult {
        val door = byId(doorId) ?: return OpenResult.MissingRequirements
        if (player.openedDoors.contains(doorId)) return OpenResult.AlreadyOpened
        val hasAll = door.requiredItems.all { (id, q) -> player.hasItem(id, q) }
        if (!hasAll) return OpenResult.MissingRequirements

        if (door.consumesItems) {
            door.requiredItems.forEach { (id, q) -> player.removeItem(id, q) }
        }
        player.openedDoors.add(doorId)
        val stack = ItemStack(door.reward, door.rewardQty)
        player.addItem(door.reward, door.rewardQty)
        return OpenResult.Success(stack)
    }
}

// ---- 2. Shareable world-controlling artifacts ------------------------------

/**
 * A world power: a singular artifact whose holder can trigger a global effect.
 * Designed so it can be PASSED between players (e.g. a guild sharing a staff).
 */
data class WorldPower(
    val id: String,
    val name: String,
    val description: String,
    /** Cooldown between activations, in seconds, enforced server-side. */
    val cooldownSeconds: Long,
    val artifactItem: Item
)

object WorldPowers {

    val STAFF_OF_THE_TURNING = WorldPower(
        id = "wp_staff_turning",
        name = "Staff of the Turning Sky",
        description = "Holder may invert the world's day/night cycle for all players, " +
                "temporarily altering which monsters spawn and which gathering nodes are rich.",
        cooldownSeconds = 6 * 60 * 60, // 6h
        artifactItem = Item(
            id = "secret_staff_turning",
            name = "Staff of the Turning Sky",
            rarity = Rarity.MYTHIC,
            slot = EquipSlot.MAIN_HAND,
            tradeable = true, // CAN be passed between players, unlike the master wand
            visibleStats = listOf(StatMod(Stat.POWER, flat = 80.0), StatMod(Stat.RIFT_RESONANCE, flat = 40.0)),
            hiddenStats = listOf(StatMod(Stat.MANA, percent = 100.0)),
            synergyTags = setOf("celestial_drift", "polearm", "world_power"),
            flags = setOf("world_power"),
            flavor = "Whoever holds it nudges the heavens for everyone."
        )
    )
}

/**
 * Authoritative (server-side) registry of who currently holds each world power
 * and when it was last used. In production this lives in the backend DB; the
 * in-memory version here documents the contract.
 */
class WorldPowerLedger {
    private data class Holding(var holderPlayerId: String?, var lastUsedEpochMs: Long)

    private val holdings = mutableMapOf<String, Holding>()

    fun currentHolder(powerId: String): String? = holdings[powerId]?.holderPlayerId

    /** Transfer the artifact (and thus the power) from one player to another. */
    fun pass(powerId: String, toPlayerId: String) {
        val h = holdings.getOrPut(powerId) { Holding(null, 0L) }
        h.holderPlayerId = toPlayerId
    }

    sealed class ActivationResult {
        object Activated : ActivationResult()
        object NotHolder : ActivationResult()
        data class OnCooldown(val secondsRemaining: Long) : ActivationResult()
    }

    fun activate(power: WorldPower, byPlayerId: String, nowMs: Long): ActivationResult {
        val h = holdings.getOrPut(power.id) { Holding(null, 0L) }
        if (h.holderPlayerId != byPlayerId) return ActivationResult.NotHolder
        val elapsed = (nowMs - h.lastUsedEpochMs) / 1000
        if (elapsed < power.cooldownSeconds) {
            return ActivationResult.OnCooldown(power.cooldownSeconds - elapsed)
        }
        h.lastUsedEpochMs = nowMs
        return ActivationResult.Activated
    }
}
