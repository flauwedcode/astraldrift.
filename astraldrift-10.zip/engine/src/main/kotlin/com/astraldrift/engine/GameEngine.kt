package com.astraldrift.engine

import kotlin.math.max
import kotlin.random.Random

/**
 * The idle engine. A player selects one [SkillAction]; the engine advances it
 * on a tick, applying the relevant speed stat to shorten duration, then awards
 * XP and rolls the drop table on completion. Offline progress is handled by
 * fast-forwarding elapsed time.
 */
class GameEngine(private val rng: Random = Random.Default) {

    data class ActionState(
        val action: SkillAction,
        var elapsedMs: Long = 0L
    )

    data class TickReport(
        val completions: Int,
        val xpGained: Long,
        val drops: List<ItemStack>,
        val levelUps: List<LevelUpResult>
    )

    /** Effective duration after applying haste / gather / production speed AND proficiency. */
    fun effectiveDuration(player: Player, action: SkillAction): Long {
        val stats = player.effectiveStats()
        val speedStat = when (action.skill.type) {
            SkillType.GATHERING -> stats[Stat.GATHER_SPEED] ?: 0.0
            SkillType.PRODUCTION -> stats[Stat.PRODUCTION_SPEED] ?: 0.0
            SkillType.COMBAT -> stats[Stat.HASTE] ?: 0.0
        }
        // Proficiency: you get faster at a skill as you master it (the "factory" ramp).
        val proficiency = Mastery.actionSpeedMultiplier(player.skill(action.skill).level)
        val factor = (1.0 + speedStat / 100.0) * proficiency
        return max(250L, (action.baseDurationMs / factor).toLong())
    }

    /**
     * Advance [state] by [deltaMs]. Resolves as many completions as fit,
     * awarding XP (boosted by XP_GAIN) and rolling drops (boosted by LUCK).
     */
    fun tick(player: Player, state: ActionState, deltaMs: Long): TickReport {
        if (player.skill(state.action.skill).level < state.action.levelRequirement) {
            return TickReport(0, 0, emptyList(), emptyList())
        }

        val stats = player.effectiveStats()
        val xpMult = 1.0 + (stats[Stat.XP_GAIN] ?: 0.0) / 100.0
        val luck = stats[Stat.LUCK] ?: 0.0
        val dur = effectiveDuration(player, state.action)

        state.elapsedMs += deltaMs
        var completions = 0
        var totalXp = 0L
        val drops = mutableListOf<ItemStack>()
        val levelUps = mutableListOf<LevelUpResult>()

        while (state.elapsedMs >= dur) {
            state.elapsedMs -= dur
            completions++

            val xp = (state.action.xpReward * xpMult).toLong()
            totalXp += xp
            val lvl = player.skill(state.action.skill).addXp(xp)
            if (lvl.leveled) levelUps.add(lvl)

            DropTables[state.action.dropTableId].roll(luck, rng)?.let { stack ->
                // Factory bulk-yield multiplies only mundane, stackable materials,
                // so it never inflates rare/celestial/mythic drop rates.
                val factoryEligible = stack.item.stackable &&
                    (stack.item.rarity == Rarity.COMMON || stack.item.rarity == Rarity.UNCOMMON)
                val mult = if (factoryEligible)
                    Mastery.rollBulkYield(player.skill(state.action.skill).level, rng) else 1
                val finalStack = if (mult > 1) stack.copy(quantity = stack.quantity * mult) else stack
                drops.add(finalStack)
                player.addItem(finalStack.item, finalStack.quantity)
            }
        }
        return TickReport(completions, totalXp, drops, levelUps)
    }

    /**
     * Offline catch-up: fast-forward [offlineMs] for the action the player was
     * running. Capped at [maxOfflineMs] (default 12h) like most idle games.
     */
    fun applyOffline(
        player: Player,
        state: ActionState,
        offlineMs: Long,
        maxOfflineMs: Long = 12 * 60 * 60 * 1000L
    ): TickReport = tick(player, state, offlineMs.coerceAtMost(maxOfflineMs))
}
