package com.astraldrift.engine

/**
 * Monsters, including apex bosses gated behind maxed stats + gear + group
 * coordination. The gate is intentionally strict: a single under-geared player
 * cannot brute-force it.
 */

data class Monster(
    val id: String,
    val name: String,
    val hp: Double,
    val power: Double,
    val defense: Double,
    /** Suggested combat level to engage. */
    val recommendedLevel: Int,
    val dropTableId: String,
    val isApex: Boolean = false,
    /** Minimum party size for apex encounters. */
    val minPartySize: Int = 1,
    /** Per-player gate requirements for apex content. */
    val gate: ApexGate? = null
)

/**
 * Requirements every party member must meet for an apex boss. Checked
 * server-side before the encounter starts.
 */
data class ApexGate(
    val minCombatLevel: Int,
    val minEffectivePower: Double,
    val minEffectiveDefense: Double,
    val minRiftResonance: Double
)

object Monsters {
    val DRIFTING_MOTE = Monster("mob_mote", "Drifting Mote", hp = 40.0, power = 6.0, defense = 2.0,
        recommendedLevel = 1, dropTableId = "early_monster")

    val HOLLOW_WRETCH = Monster("mob_wretch", "Hollow Wretch", hp = 55.0, power = 8.0, defense = 3.0,
        recommendedLevel = 1, dropTableId = "early_monster")

    val THE_DEVOURER_OF_QUIET = Monster(
        id = "apex_devourer",
        name = "The Devourer of Quiet",
        hp = 5_000_000.0,
        power = 4200.0,
        defense = 1800.0,
        recommendedLevel = 200,
        dropTableId = "early_monster", // placeholder; real apex table TBD
        isApex = true,
        minPartySize = 5,
        gate = ApexGate(
            minCombatLevel = 200,
            minEffectivePower = 3000.0,
            minEffectiveDefense = 1500.0,
            minRiftResonance = 150.0
        )
    )

    val all = listOf(DRIFTING_MOTE, HOLLOW_WRETCH, THE_DEVOURER_OF_QUIET)
}

object ApexGating {

    /** Highest of a player's three combat skill levels. */
    private fun combatLevel(p: Player): Int =
        listOf(SkillId.MELEE, SkillId.RANGED, SkillId.ARCANE)
            .maxOf { p.skill(it).level }

    data class GateCheck(val passed: Boolean, val reasons: List<String>)

    /** Verify one player against an apex gate. */
    fun checkPlayer(p: Player, gate: ApexGate): GateCheck {
        val reasons = mutableListOf<String>()
        val stats = p.effectiveStats()
        if (combatLevel(p) < gate.minCombatLevel)
            reasons += "Combat level too low (need ${gate.minCombatLevel})"
        if ((stats[Stat.POWER] ?: 0.0) < gate.minEffectivePower)
            reasons += "Power too low (need ${gate.minEffectivePower})"
        if ((stats[Stat.DEFENSE] ?: 0.0) < gate.minEffectiveDefense)
            reasons += "Defense too low (need ${gate.minEffectiveDefense})"
        if ((stats[Stat.RIFT_RESONANCE] ?: 0.0) < gate.minRiftResonance)
            reasons += "Rift Resonance too low (need ${gate.minRiftResonance})"
        return GateCheck(reasons.isEmpty(), reasons)
    }

    /** Verify a whole party. Returns who fails and why. */
    fun checkParty(party: List<Player>, monster: Monster): Map<String, GateCheck> {
        val gate = monster.gate ?: return emptyMap()
        val result = party.associate { it.name to checkPlayer(it, gate) }
        return if (party.size < monster.minPartySize) {
            result + ("__party__" to GateCheck(false,
                listOf("Need ${monster.minPartySize} players, have ${party.size}")))
        } else result
    }
}
