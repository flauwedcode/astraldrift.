package com.astraldrift.engine

import kotlin.math.floor
import kotlin.math.pow

/**
 * Skill system. Breadth mirrors Milky Way Idle: gathering + production +
 * combat, each levelled by repeating timed actions that yield XP and items.
 */

enum class SkillType { GATHERING, PRODUCTION, COMBAT }

enum class SkillId(val display: String, val type: SkillType) {
    // Gathering
    STARDIVING("Stardiving", SkillType.GATHERING),
    VOIDMINING("Voidmining", SkillType.GATHERING),
    ECHO_HARVEST("Echo-Harvesting", SkillType.GATHERING),
    RIFTFISHING("Riftfishing", SkillType.GATHERING),
    DUST_FORAGE("Dust-Foraging", SkillType.GATHERING),
    // Production
    ASTRALSMITH("Astralsmithing", SkillType.PRODUCTION),
    WEAVING("Weaving", SkillType.PRODUCTION),
    ALCHEMY("Alchemy", SkillType.PRODUCTION),
    INSCRIPTION("Inscription", SkillType.PRODUCTION),
    COOKING("Cooking", SkillType.PRODUCTION),
    // Combat
    MELEE("Melee", SkillType.COMBAT),
    RANGED("Ranged", SkillType.COMBAT),
    ARCANE("Arcane", SkillType.COMBAT),
    FORTITUDE("Fortitude", SkillType.COMBAT) // HP / defense track
}

object XpCurve {
    /** Skills cap at 1000. A solo player needs ~10 years to max one (see Progression). */
    const val MAX_LEVEL = 1000

    /**
     * Incremental XP to advance from [level] to [level]+1. Smooth super-linear
     * growth: high levels cost dramatically more, while the cumulative total
     * stays well within signed-Long range (~6.3e9 at level 1000). Calibrated
     * together with Proficiency so solo time-to-max lands on ~10 years.
     */
    private fun increment(level: Int): Long =
        floor(50.0 * level.toDouble().pow(1.85) + 100.0 * level).toLong()

    // Precomputed once at load: cumulative[L] = total XP required to *reach* level L.
    private val cumulative: LongArray = LongArray(MAX_LEVEL + 1).also { arr ->
        var total = 0L
        for (l in 1 until MAX_LEVEL) {
            total += increment(l)
            arr[l + 1] = total
        }
    }

    val totalXpToMax: Long get() = cumulative[MAX_LEVEL]

    /** Cumulative XP required to *reach* [level] (clamped to [1, MAX_LEVEL]). */
    fun xpForLevel(level: Int): Long = cumulative[level.coerceIn(1, MAX_LEVEL)]

    /** XP needed to go from [level] to [level]+1. */
    fun xpToNext(level: Int): Long {
        if (level >= MAX_LEVEL) return 0L
        return cumulative[level + 1] - cumulative[level.coerceAtLeast(1)]
    }

    /** Highest level fully paid for by [xp]. Binary search over the table. */
    fun levelForXp(xp: Long): Int {
        if (xp <= 0L) return 1
        if (xp >= cumulative[MAX_LEVEL]) return MAX_LEVEL
        var lo = 1
        var hi = MAX_LEVEL
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (cumulative[mid] <= xp) lo = mid else hi = mid - 1
        }
        return lo
    }
}

/** Mutable progress for one skill on one player. */
class SkillProgress(val id: SkillId, var xp: Long = 0L) {
    val level: Int get() = XpCurve.levelForXp(xp)

    fun addXp(amount: Long): LevelUpResult {
        val before = level
        xp += amount
        val after = level
        return LevelUpResult(id, before, after, leveled = after > before)
    }

    fun progressToNext(): Double {
        val cur = XpCurve.xpForLevel(level)
        val next = XpCurve.xpForLevel(level + 1)
        if (next == cur) return 1.0
        return (xp - cur).toDouble() / (next - cur).toDouble()
    }
}

data class LevelUpResult(val skill: SkillId, val from: Int, val to: Int, val leveled: Boolean)

/**
 * A repeatable action belonging to a skill. The idle loop runs these on a
 * timer. [baseDurationMs] is reduced by relevant speed stats at runtime.
 */
data class SkillAction(
    val id: String,
    val skill: SkillId,
    val display: String,
    val levelRequirement: Int,
    val baseDurationMs: Long,
    val xpReward: Long,
    /** Drop table id resolved against DropTables. */
    val dropTableId: String
)

object Skills {
    /** All skills initialised at level 1 for a fresh character. */
    fun freshSet(): Map<SkillId, SkillProgress> =
        SkillId.values().associateWith { SkillProgress(it) }

    /** A small starter slice of the action catalogue. Real game has hundreds. */
    val actions: List<SkillAction> = listOf(
        SkillAction("dive_shoal", SkillId.STARDIVING, "Dive the Shallow Shoal", 1, 3000, 12, "gather_low"),
        SkillAction("mine_husk", SkillId.VOIDMINING, "Mine Void Husk", 1, 3500, 14, "gather_low"),
        SkillAction("forge_shard", SkillId.ASTRALSMITH, "Forge Star-Shard Ingot", 5, 5000, 25, "smith_basic"),
        SkillAction("brew_clarity", SkillId.ALCHEMY, "Brew Clarity Draught", 8, 6000, 40, "alch_basic"),
        SkillAction("hunt_mote", SkillId.ARCANE, "Hunt Drifting Mote", 1, 4000, 18, "early_monster"),
        SkillAction("hunt_wretch", SkillId.MELEE, "Hunt Hollow Wretch", 1, 4200, 20, "early_monster")
    )
}
