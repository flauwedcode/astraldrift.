package com.astraldrift.engine

/**
 * The Celestial Weapon set — fully original to Astral Drift.
 *
 * Each weapon carries modest VISIBLE stats and large HIDDEN stats that only
 * activate under conditions, plus a shared synergy tag ("celestial_drift").
 * Equipping multiples stacks set bonuses resolved in SynergyRegistry.
 *
 * Design goal: hit the "ultra-rare, build-defining, better together" feeling
 * without referencing any existing franchise's named weapons.
 */
object CelestialWeapons {

    val NULLPOINT_EDGE = Item(
        id = "cw_nullpoint_edge",
        name = "Nullpoint Edge",
        rarity = Rarity.CELESTIAL,
        slot = EquipSlot.MAIN_HAND,
        tradeable = true,
        visibleStats = listOf(StatMod(Stat.POWER, flat = 120.0), StatMod(Stat.CRIT_CHANCE, percent = 5.0)),
        // Hidden: scales harder the lower the wielder's current HP (read at runtime).
        hiddenStats = listOf(StatMod(Stat.CRIT_DAMAGE, percent = 40.0)),
        synergyTags = setOf("celestial_drift", "edge"),
        flavor = "A blade honed against the absence between stars."
    )

    val TIDECALLER_GLAIVE = Item(
        id = "cw_tidecaller_glaive",
        name = "Tidecaller Glaive",
        rarity = Rarity.CELESTIAL,
        slot = EquipSlot.MAIN_HAND,
        visibleStats = listOf(StatMod(Stat.POWER, flat = 95.0), StatMod(Stat.HASTE, percent = 8.0)),
        hiddenStats = listOf(StatMod(Stat.MANA_REGEN, percent = 60.0)),
        synergyTags = setOf("celestial_drift", "polearm"),
        flavor = "It hums with the rhythm of a sea that no longer exists."
    )

    val EMBERVEIL_FOCUS = Item(
        id = "cw_emberveil_focus",
        name = "Emberveil Focus",
        rarity = Rarity.CELESTIAL,
        slot = EquipSlot.OFF_HAND,
        visibleStats = listOf(StatMod(Stat.MANA, flat = 200.0), StatMod(Stat.CRIT_CHANCE, percent = 4.0)),
        hiddenStats = listOf(StatMod(Stat.POWER, percent = 18.0)),
        synergyTags = setOf("celestial_drift", "focus"),
        flavor = "Warmth caught behind glass, waiting to be spent."
    )

    val LANTERN_OF_QUIET_STARS = Item(
        id = "cw_lantern_quiet_stars",
        name = "Lantern of Quiet Stars",
        rarity = Rarity.CELESTIAL,
        slot = EquipSlot.RELIC,
        visibleStats = listOf(StatMod(Stat.LUCK, flat = 30.0)),
        // Hidden: boosts rare-drop luck dramatically; doubles when paired with any edge.
        hiddenStats = listOf(StatMod(Stat.LUCK, percent = 50.0), StatMod(Stat.RIFT_RESONANCE, flat = 15.0)),
        synergyTags = setOf("celestial_drift", "relic"),
        flavor = "Hold it up and the dark blinks back."
    )

    /**
     * The Master Wand — untradeable, character-bound, the apex secret reward.
     * Modest on paper; its hidden stats are enormous and it anchors the
     * strongest set bonus in the game.
     */
    val MASTER_WAND = Item(
        id = "secret_master_wand",
        name = "The Unspoken Wand",
        rarity = Rarity.MYTHIC,
        slot = EquipSlot.MAIN_HAND,
        tradeable = false,
        visibleStats = listOf(StatMod(Stat.POWER, flat = 60.0)),
        hiddenStats = listOf(
            StatMod(Stat.POWER, percent = 120.0),
            StatMod(Stat.CRIT_DAMAGE, percent = 150.0),
            StatMod(Stat.RIFT_RESONANCE, flat = 100.0)
        ),
        synergyTags = setOf("celestial_drift", "focus", "unspoken"),
        flags = setOf("character_bound", "apex_secret"),
        flavor = "It answers to no market. Only to you."
    )

    val all = listOf(
        NULLPOINT_EDGE, TIDECALLER_GLAIVE, EMBERVEIL_FOCUS,
        LANTERN_OF_QUIET_STARS, MASTER_WAND
    )
}
