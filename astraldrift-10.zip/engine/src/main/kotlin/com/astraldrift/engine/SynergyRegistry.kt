package com.astraldrift.engine

/**
 * Hidden synergy system.
 *
 * Bonuses are keyed off [Item.synergyTags] rather than specific item IDs, so
 * new items automatically participate by sharing a tag. None of these bonuses
 * are surfaced in tooltips — players find them by experimenting with
 * combinations. This is the "hidden attributes that make them powerful when
 * paired" mechanic.
 */
object SynergyRegistry {

    private data class Synergy(
        val name: String,
        /** Returns the bonus mods if this synergy is active for the player. */
        val resolve: (Player) -> List<StatMod>
    )

    private fun countTag(p: Player, tag: String): Int =
        p.equipment.values.count { it.synergyTags.contains(tag) }

    private val synergies = listOf(
        // Two or more celestial pieces: escalating power + resonance.
        Synergy("Drift Resonance") { p ->
            val n = countTag(p, "celestial_drift")
            if (n >= 2) listOf(
                StatMod(Stat.POWER, percent = 8.0 * n),
                StatMod(Stat.RIFT_RESONANCE, flat = 10.0 * n)
            ) else emptyList()
        },
        // Lantern + any edge: the lantern's luck doubles (extra +50%).
        Synergy("Lit Edge") { p ->
            val hasLantern = p.equipment.values.any { it.synergyTags.contains("relic") && it.id == CelestialWeapons.LANTERN_OF_QUIET_STARS.id }
            val hasEdge = countTag(p, "edge") > 0
            if (hasLantern && hasEdge) listOf(StatMod(Stat.LUCK, percent = 50.0)) else emptyList()
        },
        // Master Wand + full celestial trio: the apex synergy.
        Synergy("The Unspoken Accord") { p ->
            val hasWand = p.equipment.values.any { it.hasFlag("apex_secret") }
            val celestialCount = countTag(p, "celestial_drift")
            if (hasWand && celestialCount >= 4) listOf(
                StatMod(Stat.POWER, percent = 60.0),
                StatMod(Stat.CRIT_DAMAGE, percent = 80.0),
                StatMod(Stat.HASTE, percent = 25.0)
            ) else emptyList()
        }
    )

    fun activeBonuses(p: Player): List<StatMod> =
        synergies.flatMap { it.resolve(p) }

    /** For debugging / dev tools — which synergies are live right now. */
    fun activeNames(p: Player): List<String> =
        synergies.filter { it.resolve(p).isNotEmpty() }.map { it.name }
}
