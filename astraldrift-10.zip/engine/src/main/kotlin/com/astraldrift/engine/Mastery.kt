package com.astraldrift.engine

import kotlin.random.Random

/**
 * MASTERY — two intertwined "you get better at what you do" systems.
 *
 *  A) PROFICIENCY: the more you level a skill, the FASTER you perform it — like
 *     real life. A high-level woodcutter (or voidminer, smith, etc.) becomes a
 *     one-person factory. Speed climbs smoothly with level plus milestone leaps;
 *     this curve is part of the 10-year calibration (see Progression).
 *
 *  B) CHARACTER MASTERY BONUSES: every character also earns permanent passive
 *     stat bonuses derived from WHICH skills they've invested in. Because no two
 *     players train the same spread, the resulting stat profile is unique to
 *     each character's playstyle — "unique bonuses based on what they do."
 */
object Mastery {

    // ---- A) Proficiency: action-speed multiplier ---------------------------

    /**
     * Speed multiplier for a skill at [level]. 1.0 at level 1, ~3.65x at 1000.
     * Higher = actions resolve faster = more throughput. Matches the calibrated
     * curve in Progression / the Python model.
     */
    fun actionSpeedMultiplier(level: Int): Double {
        val linear = 1.0 + 0.0015 * level            // +0.15% per level
        var milestone = 0.0
        if (level >= 100) milestone += 0.05
        if (level >= 250) milestone += 0.10
        if (level >= 500) milestone += 0.20
        if (level >= 750) milestone += 0.30
        if (level >= 1000) milestone += 0.50
        return linear + milestone
    }

    /**
     * "Factory" bulk yield. Independent of XP (so it never breaks the time
     * calibration): a master gatherer/crafter often produces 2-3x the ITEMS per
     * action. Returns an output multiplier of 1, 2, or 3.
     */
    fun rollBulkYield(level: Int, rng: Random = Random.Default): Int {
        val tripleChance = (level / 2000.0)                  // up to 0.50 at lvl 1000
        val doubleChance = (level / 1000.0).coerceAtMost(1.0) // up to 1.00 at lvl 1000
        val r = rng.nextDouble()
        return when {
            r < tripleChance -> 3
            r < (tripleChance + doubleChance).coerceAtMost(0.95) -> 2
            else -> 1
        }
    }

    // ---- B) Character mastery: passive stat bonuses ------------------------

    /** Which stats each skill trains. Drives a player's unique stat identity. */
    private val affinity: Map<SkillId, List<Stat>> = mapOf(
        SkillId.STARDIVING to listOf(Stat.GATHER_SPEED, Stat.LUCK),
        SkillId.VOIDMINING to listOf(Stat.GATHER_SPEED, Stat.DEFENSE),
        SkillId.ECHO_HARVEST to listOf(Stat.GATHER_SPEED, Stat.RIFT_RESONANCE),
        SkillId.RIFTFISHING to listOf(Stat.GATHER_SPEED, Stat.MANA_REGEN),
        SkillId.DUST_FORAGE to listOf(Stat.GATHER_SPEED, Stat.XP_GAIN),
        SkillId.ASTRALSMITH to listOf(Stat.PRODUCTION_SPEED, Stat.POWER),
        SkillId.WEAVING to listOf(Stat.PRODUCTION_SPEED, Stat.DEFENSE),
        SkillId.ALCHEMY to listOf(Stat.PRODUCTION_SPEED, Stat.MANA),
        SkillId.INSCRIPTION to listOf(Stat.PRODUCTION_SPEED, Stat.CRIT_DAMAGE),
        SkillId.COOKING to listOf(Stat.PRODUCTION_SPEED, Stat.MANA_REGEN),
        SkillId.MELEE to listOf(Stat.POWER, Stat.CRIT_CHANCE),
        SkillId.RANGED to listOf(Stat.POWER, Stat.HASTE),
        SkillId.ARCANE to listOf(Stat.POWER, Stat.MANA),
        SkillId.FORTITUDE to listOf(Stat.DEFENSE, Stat.MANA)
    )

    /** Flat bonus granted per 100 levels, sized to the stat's natural scale. */
    private fun flatPer100(stat: Stat): Double = when (stat) {
        Stat.CRIT_DAMAGE -> 5.0
        Stat.POWER, Stat.DEFENSE, Stat.MANA, Stat.MANA_REGEN,
        Stat.LUCK, Stat.RIFT_RESONANCE -> 5.0
        // rate stats are measured in percentage points
        else -> 1.0
    }

    /**
     * Permanent passive bonuses from this character's skill investment.
     * Summed across every skill; a player's spread makes this unique to them.
     */
    fun bonuses(player: Player): List<StatMod> {
        val out = mutableListOf<StatMod>()
        for ((skill, progress) in player.skills) {
            val stats = affinity[skill] ?: continue
            val chunks = progress.level / 100          // a bonus tier every 100 levels
            if (chunks <= 0) continue
            stats.forEach { out += StatMod(it, flat = flatPer100(it) * chunks) }
        }
        return out
    }

    /** Human-readable summary of a character's dominant masteries (for UI/titles). */
    fun profile(player: Player): List<String> =
        player.skills.values
            .filter { it.level >= 100 }
            .sortedByDescending { it.level }
            .map { "${it.id.display} ${it.level}" }
}
