package com.astraldrift.engine

import kotlin.random.Random

/**
 * Loot system. Each entry has a weight; one or more rolls pick from the table.
 * "Cursed" entries (the master wand etc.) sit on otherwise-trivial early
 * monster tables with absurdly low effective probability, modified by LUCK.
 */

data class DropEntry(
    val item: Item,
    val weight: Double,
    val minQty: Int = 1,
    val maxQty: Int = 1,
    /** If true, LUCK stat improves the odds of this specific entry. */
    val luckScaled: Boolean = false
)

class DropTable(val id: String, val entries: List<DropEntry>) {

    /**
     * Rolls the table once. [luck] is the player's effective LUCK stat; it
     * proportionally boosts luck-scaled entries' weights.
     */
    fun roll(luck: Double = 0.0, rng: Random = Random.Default): ItemStack? {
        if (entries.isEmpty()) return null
        val adjusted = entries.map { e ->
            val w = if (e.luckScaled) e.weight * (1.0 + luck / 100.0) else e.weight
            e to w
        }
        val total = adjusted.sumOf { it.second }
        var pick = rng.nextDouble(total)
        for ((entry, w) in adjusted) {
            if (pick < w) {
                val qty = if (entry.maxQty > entry.minQty)
                    rng.nextInt(entry.minQty, entry.maxQty + 1) else entry.minQty
                return ItemStack(entry.item, qty)
            }
            pick -= w
        }
        return null
    }
}

object DropTables {

    // Mundane materials. Hoisted and exposed so the item catalogue (server)
    // has a single source of truth for reconstructing saved inventories.
    private val stardust = Item("mat_stardust", "Stardust", Rarity.COMMON, stackable = true)
    private val voidShard = Item("mat_void_shard", "Void Shard", Rarity.COMMON, stackable = true)
    private val faintEcho = Item("mat_faint_echo", "Faint Echo", Rarity.UNCOMMON, stackable = true)
    private val starshardIngot = Item("mat_starshard_ingot", "Star-Shard Ingot", Rarity.UNCOMMON, stackable = true)
    private val clarityDraught = Item("pot_clarity", "Clarity Draught", Rarity.UNCOMMON, stackable = true)

    val allMaterials: List<Item> = listOf(stardust, voidShard, faintEcho, starshardIngot, clarityDraught)

    private val tables = mutableMapOf<String, DropTable>()

    init {
        tables["gather_low"] = DropTable("gather_low", listOf(
            DropEntry(stardust, weight = 700.0, minQty = 1, maxQty = 3),
            DropEntry(voidShard, weight = 280.0, minQty = 1, maxQty = 2),
            DropEntry(faintEcho, weight = 20.0)
        ))

        tables["smith_basic"] = DropTable("smith_basic", listOf(
            DropEntry(starshardIngot, 1000.0)
        ))

        tables["alch_basic"] = DropTable("alch_basic", listOf(
            DropEntry(clarityDraught, 1000.0)
        ))

        // EARLY MONSTER TABLE — the important one.
        // Trash mob drops mostly junk, but carries two extremely rare secret
        // drops. The master wand's effective rate is ~ 1 / 1,000,000 at zero
        // luck (weight 0.001 against a total of ~1000). Even maxed luck only
        // nudges it. This is your "abysmal drop rate, build-defining" hook.
        tables["early_monster"] = DropTable("early_monster", listOf(
            DropEntry(stardust, weight = 600.0, minQty = 1, maxQty = 4),
            DropEntry(voidShard, weight = 350.0, minQty = 1, maxQty = 3),
            DropEntry(faintEcho, weight = 49.0),
            DropEntry(CelestialWeapons.NULLPOINT_EDGE, weight = 0.5, luckScaled = true),      // very rare
            DropEntry(CelestialWeapons.MASTER_WAND, weight = 0.001, luckScaled = true)        // abysmal
        ))
    }

    operator fun get(id: String): DropTable =
        tables[id] ?: error("Unknown drop table: $id")
}
