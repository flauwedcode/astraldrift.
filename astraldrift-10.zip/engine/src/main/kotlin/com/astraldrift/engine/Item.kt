package com.astraldrift.engine

/**
 * Item model for Astral Drift.
 *
 * Design notes:
 *  - [tradeable] is enforced at the item level. The master wand, world-power
 *    artifacts, and door rewards all set this to false so the trading/market
 *    layer can reject them with a single check.
 *  - [visibleStats] are shown in tooltips. [hiddenStats] are NOT — players
 *    discover them by experimentation. This is what makes synergy hunting fun.
 *  - [synergyTags] let multiple items recognise each other for set bonuses
 *    without hard-coding pairs everywhere (see SynergyRegistry).
 */

enum class Rarity(val displayName: String, val colorHex: String, val weight: Double) {
    COMMON("Common", "#9AA0A6", 1000.0),
    UNCOMMON("Uncommon", "#3CB371", 250.0),
    RARE("Rare", "#4D8BF0", 60.0),
    EPIC("Epic", "#9B59B6", 12.0),
    CELESTIAL("Celestial", "#E8B339", 1.0),
    // Reserved for cursed/secret drops. Never appears in normal rolls — only
    // explicit hand-authored drop entries can grant this tier.
    MYTHIC("Mythic", "#FF5470", 0.0)
}

enum class EquipSlot {
    MAIN_HAND, OFF_HAND, HEAD, CHEST, LEGS, FEET, RING, AMULET, RELIC, NONE
}

/**
 * A single stat modifier. Additive flat values and multiplicative percent
 * values are kept separate so the stat resolver can apply them in the right
 * order (flats first, then multipliers).
 */
data class StatMod(
    val stat: Stat,
    val flat: Double = 0.0,
    val percent: Double = 0.0
)

enum class Stat {
    POWER, DEFENSE, HASTE, CRIT_CHANCE, CRIT_DAMAGE,
    MANA, MANA_REGEN, LUCK, RIFT_RESONANCE,   // RIFT_RESONANCE gates several secrets
    GATHER_SPEED, PRODUCTION_SPEED, XP_GAIN
}

data class Item(
    val id: String,
    val name: String,
    val rarity: Rarity,
    val slot: EquipSlot = EquipSlot.NONE,
    val tradeable: Boolean = true,
    val stackable: Boolean = false,
    val visibleStats: List<StatMod> = emptyList(),
    val hiddenStats: List<StatMod> = emptyList(),
    val synergyTags: Set<String> = emptySet(),
    /** Free-form flags read by the secrets layer, e.g. "key:void", "world_power". */
    val flags: Set<String> = emptySet(),
    val flavor: String = ""
) {
    val isUntradeable get() = !tradeable
    fun hasFlag(f: String) = flags.contains(f)
}

/** A quantity of an item sitting in an inventory. */
data class ItemStack(val item: Item, val quantity: Int = 1)
