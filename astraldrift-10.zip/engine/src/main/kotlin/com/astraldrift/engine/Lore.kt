package com.astraldrift.engine

/**
 * LORE — the world of Astral Drift.
 *
 * All original. These strings are the canonical worldbuilding the UI, codex,
 * quests, and item descriptions draw from. Keep additions consistent with the
 * core premise below.
 */
object Lore {

    val SETTING = """
        THE THINNING

        The sky did not fall. It thinned.

        No one agrees on the year it began — only that the stars started arriving
        late. Light that should have taken an age to cross the dark began to skip,
        to stutter, to repeat. Astronomers called it parallax error until the
        morning two moons rose and only one was real. After that they stopped
        calling it anything.

        The world we walk now sits on the worn edge of something the old texts
        name only as the Quiet: the place between places, where distance forgets
        itself and time pools like water in a footprint. Reality is thinnest here,
        and through the thin spots drift the things that the Quiet has been keeping.
    """.trimIndent()

    val DRIFTERS = """
        DRIFTERS

        You are a Drifter — one of the few who can step sideways through a thin
        spot and come back with your name intact. Most who try return as echoes,
        or do not return at all. Drifters are scavengers, cartographers of the
        impossible, and, increasingly, the only thing standing between the towns
        and what comes through when the Quiet exhales.

        A Drifter's craft is patience. The Quiet does not reward haste; it rewards
        return. Those who come back to the same shoal, the same vein, the same
        quiet ritual, day after day, find the world slowly bending to fit their
        hands. This is no metaphor. Mastery here is literal: the longer you do a
        thing, the more the thinned world lets you do it. Old Drifters move like
        the laws were written for them.
    """.trimIndent()

    val RESONANCE_AND_DRIFT_TIME = """
        RESONANCE & DRIFT-TIME

        Two forces shape a Drifter's life.

        RIFT RESONANCE is how loudly you ring against the thin places. The
        resonant are found by rare things — and by rarer things still. Resonance
        is grown, not given: through deep gear, through the relics of the Quiet,
        through standing where others flee.

        DRIFT-TIME is the strangest mercy of the Thinning. Because time pools in
        the Quiet, a Drifter never truly loses the hours they spend away. Step out
        of the world for a season — or a decade — and the drift-time you accrued
        is still there when you return, waiting to be spent on the crafts you left
        unfinished. Some say the Quiet keeps your hours so you'll always have a
        reason to come back. (Mechanically: Idle Essence never decays. See
        IdleEssence.kt.)
    """.trimIndent()

    val ECHOES_AND_PETS = """
        ECHOES

        Not everything that drifts through the thin places is hungry. Some are
        only curious. An Echo is a fragment of the Quiet that has watched a Drifter
        do something it did not think a person could do — and decided to follow
        them to see if they'll do it again.

        You cannot buy an Echo. You cannot trade for one. You cannot even reliably
        find one; they find you, and only after a feat large enough to be heard
        across the thin. Two Drifters are almost never noticed for the same reason,
        because the Quiet measures each of us against our own life, not against a
        ledger. What earns one Drifter a companion would not stir the air for
        another.
    """.trimIndent()

    val CELESTIAL_ARMS = """
        THE CELESTIAL ARMS

        A handful of weapons in the world were not forged. They condensed — out of
        grief, out of tide, out of the warmth behind a dying star — and fell into
        the thinned world fully made. The Drifters who study them call them the
        Celestial Arms. Apart, each is merely extraordinary. Together, they
        remember that they were once a single thing, and what they remember, they
        return to you as power.

        Most prized, and least understood, is the wand that answers to no market —
        the Unspoken. It cannot be sold, traded, or taken. It chooses a hand and
        stays. Those who carry one rarely say how they came by it.
    """.trimIndent()

    val WORLD_POWERS = """
        THE TURNING

        Rarest of all are the arms that do not change the wielder but the world.
        The Staff of the Turning Sky is the only one most Drifters will ever hear
        named: hold it, and you may invert the hours for everyone alive, pulling
        new things into the light and sending others back to sleep. Such power is
        too heavy for one hand for long. It is meant to be passed — guild to guild,
        friend to friend — a shared key to the world's clock.
    """.trimIndent()

    val THE_DEVOURER = """
        THE DEVOURER OF QUIET

        There is a hunger at the bottom of the Quiet that has no name of its own,
        so we lend it ours. The Devourer is not evil; it is appetite the size of an
        absence. No Drifter has ever faced it alone and returned. It is not a test
        of strength but of everything at once — mastery, gear, resonance, and, above
        all, the willingness to stand in a line beside others and not break.
        Whatever drops from it, drops only for those who held that line together.
    """.trimIndent()

    /** Convenience: the whole codex in reading order. */
    val codex: List<Pair<String, String>> = listOf(
        "The Thinning" to SETTING,
        "Drifters" to DRIFTERS,
        "Resonance & Drift-Time" to RESONANCE_AND_DRIFT_TIME,
        "Echoes" to ECHOES_AND_PETS,
        "The Celestial Arms" to CELESTIAL_ARMS,
        "The Turning" to WORLD_POWERS,
        "The Devourer of Quiet" to THE_DEVOURER
    )
}
