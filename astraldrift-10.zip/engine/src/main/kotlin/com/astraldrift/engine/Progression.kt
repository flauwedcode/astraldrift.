package com.astraldrift.engine

/**
 * PROGRESSION CALIBRATION.
 *
 * Headline design targets:
 *   • Solo, no external help:            ~10 years to max ONE skill (level 1000)
 *   • With gear + guild + teamwork:      ~7 years
 *
 * The reduction comes from a flat THROUGHPUT multiplier built from three
 * stacking sources (additive), so the 7-year figure is exact and tunable:
 *
 *      gear (+18%) + guild (+15%) + teamwork (+10%)  =  +43%
 *      10 years / 1.43  ≈  7.0 years
 *
 * [estimateYearsToMax] reproduces the same integral used to calibrate the curve
 * (Xp increments / effective XP-per-second, folding in Proficiency), so the demo
 * can print these numbers rather than asserting them.
 */
object Progression {

    /** Calibrated reference throughput at level 1 with no boosts (XP/second). */
    const val BASE_XP_PER_SECOND: Double = 7.9907

    const val GEAR_BONUS: Double = 0.18
    const val GUILD_BONUS: Double = 0.15
    const val TEAMWORK_BONUS: Double = 0.10

    private const val YEAR_SECONDS: Double = 365.25 * 24 * 3600

    /** Full stacked external multiplier (≈ 1.43). */
    fun fullExternalMultiplier(): Double =
        1.0 + GEAR_BONUS + GUILD_BONUS + TEAMWORK_BONUS

    /**
     * Estimated years to take ONE skill from level 1 to [XpCurve.MAX_LEVEL],
     * given an external throughput [externalMultiplier] (1.0 = solo). Folds in
     * the Proficiency speed curve, exactly like the calibration.
     */
    fun estimateYearsToMax(externalMultiplier: Double = 1.0): Double {
        var seconds = 0.0
        for (level in 1 until XpCurve.MAX_LEVEL) {
            val effRate = BASE_XP_PER_SECOND *
                Mastery.actionSpeedMultiplier(level) *
                externalMultiplier
            seconds += XpCurve.xpToNext(level) / effRate
        }
        return seconds / YEAR_SECONDS
    }

    fun soloYearsToMax(): Double = estimateYearsToMax(1.0)
    fun boostedYearsToMax(): Double = estimateYearsToMax(fullExternalMultiplier())
}
