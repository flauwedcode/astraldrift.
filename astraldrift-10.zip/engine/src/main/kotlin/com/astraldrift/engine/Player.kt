package com.astraldrift.engine

import java.util.UUID

/**
 * Stats that scale multiplicatively (flat magnitude amplified by % bonuses).
 * Everything else (haste, crit, gather/production speed, xp gain) is a rate
 * measured in percentage points and accumulates additively.
 */
private val MAGNITUDE_STATS: Set<Stat> = setOf(
    Stat.POWER, Stat.DEFENSE, Stat.MANA, Stat.MANA_REGEN, Stat.LUCK, Stat.RIFT_RESONANCE
)

/**
 * Player state. Holds skills, inventory, and equipped items, and is the entry
 * point for resolving effective stats (which folds in hidden synergy bonuses).
 */
class Player(
    val id: String = UUID.randomUUID().toString(),
    val name: String
) {
    val skills: MutableMap<SkillId, SkillProgress> = Skills.freshSet().toMutableMap()
    val inventory: MutableList<ItemStack> = mutableListOf()
    val equipment: MutableMap<EquipSlot, Item> = mutableMapOf()

    /** Idle Essence ledger — the "never lose progress" system. See IdleEssence.kt. */
    val essence: EssenceAccount = EssenceAccount()

    /** Tradeable economy currency, used by the market and direct trades. */
    var shards: Long = 0L

    var currentHp: Double = 100.0
    var maxHp: Double = 100.0

    /** Tracks which one-time secret doors this player has already opened. */
    val openedDoors: MutableSet<String> = mutableSetOf()

    // ---- Inventory helpers -------------------------------------------------

    fun addItem(item: Item, qty: Int = 1) {
        if (item.stackable) {
            val existing = inventory.find { it.item.id == item.id }
            if (existing != null) {
                inventory[inventory.indexOf(existing)] = existing.copy(quantity = existing.quantity + qty)
                return
            }
        }
        inventory.add(ItemStack(item, qty))
    }

    fun hasItem(itemId: String, qty: Int = 1): Boolean =
        inventory.filter { it.item.id == itemId }.sumOf { it.quantity } >= qty

    fun removeItem(itemId: String, qty: Int = 1): Boolean {
        if (!hasItem(itemId, qty)) return false
        var remaining = qty
        val it = inventory.iterator()
        while (it.hasNext() && remaining > 0) {
            val stack = it.next()
            if (stack.item.id == itemId) {
                val take = minOf(stack.quantity, remaining)
                remaining -= take
                if (stack.quantity - take <= 0) it.remove()
                else inventory[inventory.indexOf(stack)] = stack.copy(quantity = stack.quantity - take)
            }
        }
        return true
    }

    fun equip(item: Item) {
        if (item.slot == EquipSlot.NONE) return
        equipment[item.slot] = item
    }

    // ---- Stat resolution ---------------------------------------------------

    /**
     * Effective stats = base + all equipped visible stats + all equipped HIDDEN
     * stats + synergy bonuses from SynergyRegistry. Flats applied first, then
     * percent multipliers, per stat.
     */
    fun effectiveStats(): Map<Stat, Double> {
        val flats = mutableMapOf<Stat, Double>()
        val pcts = mutableMapOf<Stat, Double>()

        fun apply(mods: List<StatMod>) {
            for (m in mods) {
                flats[m.stat] = (flats[m.stat] ?: 0.0) + m.flat
                pcts[m.stat] = (pcts[m.stat] ?: 0.0) + m.percent
            }
        }

        equipment.values.forEach {
            apply(it.visibleStats)
            apply(it.hiddenStats) // hidden stats are real, just not shown in tooltips
        }

        // Fold in discovered synergy bonuses and character mastery.
        apply(SynergyRegistry.activeBonuses(this))
        apply(Mastery.bonuses(this))

        val result = mutableMapOf<Stat, Double>()
        val allStats = (flats.keys + pcts.keys)
        for (s in allStats) {
            val flat = flats[s] ?: 0.0
            val pct = pcts[s] ?: 0.0
            // Magnitude stats scale multiplicatively (flat * (1 + pct%)).
            // Rate/percentage stats accumulate additively in points.
            result[s] = if (s in MAGNITUDE_STATS) flat * (1.0 + pct / 100.0) else flat + pct
        }
        return result
    }

    fun skill(id: SkillId): SkillProgress = skills.getValue(id)
}
