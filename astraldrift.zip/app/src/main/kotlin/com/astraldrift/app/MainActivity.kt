package com.astraldrift.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.astraldrift.app.ui.GameViewModel

/**
 * Single-screen client. The engine runs inside GameViewModel; this just draws the
 * state it emits and forwards a couple of taps. Progress is saved by Room (autosave
 * every 15s + on background), and offline gains are applied on the next launch.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GameScreen()
                }
            }
        }
    }
}

@Composable
fun GameScreen(viewModel: GameViewModel = viewModel()) {
    val ui by viewModel.ui.collectAsState()

    // Save whenever the app is sent to the background.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) viewModel.saveNow()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!ui.loaded) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(12.dp))
                Text("Loading your drift...")
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Astral Drift",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Engine live on-device - running for ${ui.runningSeconds}s",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (ui.welcomeBackSeconds > 0) {
            ElevatedCard {
                Column(Modifier.padding(16.dp)) {
                    Text("Welcome back", fontWeight = FontWeight.SemiBold)
                    Text(
                        "You were away ${formatDuration(ui.welcomeBackSeconds)} - " +
                            "progress kept accruing.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        ElevatedCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Activity: ${ui.activity}", fontWeight = FontWeight.SemiBold)
                Text("${ui.skillName} - level ${ui.level}")
                LinearProgressIndicator(
                    progress = { ui.progress },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Actions completed: ${ui.totalCompletions}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalButton(
                onClick = { viewModel.selectAction("dive_shoal") },
                enabled = ui.selectedActionId != "dive_shoal"
            ) { Text("Gather") }
            FilledTonalButton(
                onClick = { viewModel.selectAction("hunt_wretch") },
                enabled = ui.selectedActionId != "hunt_wretch"
            ) { Text("Fight") }
        }

        Button(onClick = { viewModel.skipOneMinute() }) { Text("Skip 1 minute") }

        ElevatedCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Idle Essence", fontWeight = FontWeight.SemiBold)
                Text(formatNumber(ui.essence), fontFamily = FontFamily.Monospace)
                Text(
                    "Accrues in real time, even while closed.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        ElevatedCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Inventory", fontWeight = FontWeight.SemiBold)
                if (ui.inventory.isEmpty()) {
                    Text("Empty - give it a few seconds.", style = MaterialTheme.typography.bodySmall)
                } else {
                    ui.inventory.forEach { (name, qty) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(name)
                            Text("x$qty", fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

private fun formatNumber(value: Double): String =
    if (value >= 1000) "%,.0f".format(value) else "%.1f".format(value)

private fun formatDuration(seconds: Long): String = when {
    seconds < 60 -> "${seconds}s"
    seconds < 3600 -> "${seconds / 60}m"
    seconds < 86400 -> "${seconds / 3600}h"
    else -> "${seconds / 86400}d"
}
