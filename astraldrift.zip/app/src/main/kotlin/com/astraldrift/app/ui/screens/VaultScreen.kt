package com.astraldrift.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.astraldrift.app.ui.GameUiState
import com.astraldrift.app.ui.InventoryUiItem
import com.astraldrift.app.ui.theme.*
import com.astraldrift.engine.EssenceConfig
import com.astraldrift.engine.SkillId
import com.astraldrift.engine.SkillType

@Composable
fun VaultScreen(
    ui: GameUiState,
    onSpendEssence: (SkillId) -> Unit
) {
    val eligibleSkills = ui.skills.filter { it.type != SkillType.COMBAT }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpace)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
    ) {
        // Essence balance card
        item {
            SectionLabel("IDLE ESSENCE")
            Spacer(Modifier.height(10.dp))
            GlowCard {
                Column(
                    Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Big balance number
                    Text(
                        formatEssence(ui.essence),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 40.sp,
                        color = Starlight
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "+${formatEssence(ui.essencePerMinute)}/min",
                            fontSize = 12.sp,
                            color = CeruleanGlow,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            "Ceiling: Lv ${ui.essenceCeilingLevel}",
                            fontSize = 11.sp,
                            color = StarlightMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Divider(color = NebulaPurple.copy(alpha = 0.25f), thickness = 0.5.dp)
                    Text(
                        "Accrues in real time. Never lost. Spend on non-combat skills up to Lv ${EssenceConfig.CEILING_LEVEL}.",
                        fontSize = 11.sp,
                        color = StarlightMuted,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Spend section
        item {
            SectionLabel("SPEND ESSENCE")
            Spacer(Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                eligibleSkills.forEach { skill ->
                    val isSelected = false
                    val atCeiling = skill.level >= EssenceConfig.CEILING_LEVEL
                    val previewLevel = if (ui.essence > 0 && !atCeiling) {
                        minOf(EssenceConfig.CEILING_LEVEL, skill.level + (ui.essence / 10000).toInt().coerceAtLeast(1))
                    } else skill.level

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(skill.display, color = if (atCeiling) StarlightMuted else Starlight, fontSize = 13.sp)
                            Text(
                                if (atCeiling) "At ceiling" else "Lv ${skill.level} → ~$previewLevel",
                                fontSize = 11.sp,
                                color = if (atCeiling) StarlightMuted.copy(0.5f) else CeruleanGlow,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Button(
                            onClick = { onSpendEssence(skill.id) },
                            enabled = ui.essence > 0 && !atCeiling,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CeruleanGlow.copy(alpha = 0.15f),
                                contentColor = CeruleanGlow,
                                disabledContainerColor = DarkPanel,
                                disabledContentColor = StarlightMuted.copy(0.4f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text("Spend", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                    Divider(color = NebulaPurple.copy(alpha = 0.15f), thickness = 0.5.dp)
                }
            }
        }

        // Inventory
        item { SectionLabel("INVENTORY") }

        if (ui.inventoryItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Nothing yet — train to gather loot.",
                        color = StarlightMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(ui.inventoryItems.chunked(2)) { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { item ->
                        ItemChip(item = item, modifier = Modifier.weight(1f))
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ItemChip(item: InventoryUiItem, modifier: Modifier = Modifier) {
    // Extract RGBA components from the packed ARGB Long — works regardless of
    // which Color(Long) overload Compose exposes in this BOM version.
    val argb = item.rarityArgb
    val rarityColor = androidx.compose.ui.graphics.Color(
        alpha = ((argb ushr 24) and 0xFFL).toFloat() / 255f,
        red   = ((argb ushr 16) and 0xFFL).toFloat() / 255f,
        green = ((argb ushr  8) and 0xFFL).toFloat() / 255f,
        blue  = ( argb          and 0xFFL).toFloat() / 255f
    )
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkPanel)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(
                item.name,
                color = Starlight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Text(
                "x${item.qty}",
                color = CeruleanGlow,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Box(
            modifier = Modifier
                .background(rarityColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                item.rarityLabel,
                fontSize = 9.sp,
                color = rarityColor,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
        }
    }
}

private fun formatEssence(value: Double): String = when {
    value >= 1_000_000 -> "%.1fM".format(value / 1_000_000)
    value >= 1_000 -> "%.1fK".format(value / 1_000)
    else -> "%.1f".format(value)
}
