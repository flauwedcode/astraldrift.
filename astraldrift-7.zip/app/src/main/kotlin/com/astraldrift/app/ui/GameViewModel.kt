package com.astraldrift.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.astraldrift.app.game.GameRepository
import com.astraldrift.engine.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Everything the screen needs to draw, as immutable state. */
data class GameUiState(
    val loaded: Boolean = false,
    val activity: String = "",
    val skillName: String = "",
    val level: Int = 0,
    val progress: Float = 0f,
    val totalCompletions: Long = 0L,
    val essence: Double = 0.0,
    val selectedActionId: String = "",
    val inventory: List<Pair<String, Int>> = emptyList(),
    val runningSeconds: Long = 0L,
    val welcomeBackSeconds: Long = 0L
)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(app)
    private val engine = GameEngine()

    private lateinit var player: Player
    private var selectedActionId = repo.defaultActionId
    private var actionState: GameEngine.ActionState? = null
    private var totalCompletions = 0L
    private val startedAt = System.currentTimeMillis()
    private var welcomeBackSeconds = 0L

    private val _ui = MutableStateFlow(GameUiState())
    val ui: StateFlow<GameUiState> = _ui.asStateFlow()

    private var loopJob: Job? = null

    init {
        viewModelScope.launch {
            val loaded = repo.loadOrCreate()
            player = loaded.player
            selectedActionId = loaded.selectedActionId
            actionState = GameEngine.ActionState(currentAction())
            welcomeBackSeconds = loaded.offlineSeconds
            refresh()
            startLoop()
        }
    }

    private fun currentAction(): SkillAction =
        Skills.actions.first { it.id == selectedActionId }

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = viewModelScope.launch {
            var ticksSinceSave = 0
            while (isActive) {
                delay(1000L)
                val report = engine.tick(player, actionState!!, 1000L)
                player.essence.accrue(System.currentTimeMillis())
                totalCompletions += report.completions
                welcomeBackSeconds = 0L      // clear the welcome-back banner after first tick
                refresh()
                if (++ticksSinceSave >= 15) {  // autosave every 15s
                    repo.save(player, selectedActionId)
                    ticksSinceSave = 0
                }
            }
        }
    }

    fun selectAction(id: String) {
        if (!::player.isInitialized || id == selectedActionId) return
        selectedActionId = id
        actionState = GameEngine.ActionState(currentAction())
        refresh()
        viewModelScope.launch { repo.save(player, selectedActionId) }
    }

    fun skipOneMinute() {
        if (!::player.isInitialized) return
        val report = engine.tick(player, actionState!!, 60_000L)
        totalCompletions += report.completions
        player.essence.lastAccrualEpochMs -= 60_000L
        player.essence.accrue(System.currentTimeMillis())
        refresh()
    }

    /** Called from the Activity lifecycle (e.g. when backgrounded). */
    fun saveNow() {
        if (!::player.isInitialized) return
        viewModelScope.launch { repo.save(player, selectedActionId) }
    }

    private fun refresh() {
        if (!::player.isInitialized) return
        val skill = player.skill(currentAction().skill)
        _ui.value = GameUiState(
            loaded = true,
            activity = currentAction().display,
            skillName = currentAction().skill.display,
            level = skill.level,
            progress = skill.progressToNext().toFloat().coerceIn(0f, 1f),
            totalCompletions = totalCompletions,
            essence = player.essence.balance,
            selectedActionId = selectedActionId,
            inventory = player.inventory.map { it.item.name to it.quantity },
            runningSeconds = (System.currentTimeMillis() - startedAt) / 1000,
            welcomeBackSeconds = welcomeBackSeconds
        )
    }
}
